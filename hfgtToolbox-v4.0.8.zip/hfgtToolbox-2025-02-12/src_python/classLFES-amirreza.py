"""
Copyright (c) 2018-2024 Engineering Systems Analytics LLC
@author: Amro M. Farid
@version 4.0
@Note:  Version 4.0 is a major release constituting a full rewrite of the entire code base.
@Acknowledgement:  Thanks goes to Dr. Amro M. Farid, Dr. Wester C. H. Schoonenberg, and Dr. Dakota Thompson as the principal
                    authors of Versions 1, 2, 3 respectively.
@Modified: 06/01/2024
@ Provided under the Creative Commons 4.0 License
"""
import sys  # Needed for the parent function
import os
import subprocess
import pathlib as pl
import shutil
import time
from datetime import datetime
import re
import copy
import xml.etree.ElementTree as ET
import json
import csv
# These require specific instalation
import numpy as np
from scipy.sparse import (coo_array, csc_array, dok_array, block_diag, hstack, vstack, kron, diags_array, issparse, bmat, eye)
# For 2-D sparse matricces.  Use COO by default, CSC for vector operations, and DOK for element access
from sparse import DOK # For N-D sparse tensors, DOK is the easiest way to construct the tensor
from sparse import COO # For N_D sparse tensors, COO is the default storage format of the toolbox
from numba import njit

from dicttoxml import dicttoxml
import xmltodict
import bsdf
from oct2py import octave
import oct2py.io
import cProfile
import pstats

## Main Analytical Function
def runHFGTAnalysis(xmlFilePath: str):
    """
    Runs HFGT analysis using the provided XML file.

    :param xml_file: XML file to use for analysis
    :param verbose_mode: 0=Basic, 1=Parallel, 2=Incidence, 3=Julia
    :param out_dir: output directory to save resulting pickle.  Default is ./output
    :return: absolute path to which the pickle was saved
    """
    startTime = time.time()
    myLFES = LFES() # Initialize the LFES Structure. LFES() is in xml2lfes_classinitialization.py
    myLFES.populateXMLData(xmlFilePath)
    myLFES.produceFinalLFES()
    print('Success! Analysis Complete!  Total computation time taken: %f' % (time.time() - startTime))
    outputFilePath = saveMyData(myLFES)
    print('Success! Data Saved!  Total computation & writing time taken: %f' % (time.time() - startTime))
    # This is purely for demonstration purposes that we can re-import the output file without loss.
    myLFES2 = loadMyData(outputFilePath)
    myResult,myString = debugEquivObjs(myLFES,myLFES2)
    return myLFES
## LFES ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class LFES:
    '''Represents all of the components in the HFGT toolbox LFES structure'''
    def __init__(self):
        self.name = []
        self.scenario = []
        self.refArchitecture = []
        self.dataState = []
        self.version = []
        self.runCode = []
        self.verboseMode = []
        self.analyzeSoS = []
        self.inputDataFormat = []
        self.inputFilePath = []
        self.outputFileType = []
        self.outputDirectory = pl.Path('1_Output_Data/')
        self.outputDataFormat = ['full']

        self.operand = Operand()
        self.sosService = Operand()

        self.transformationResource = TransformationResource()
        self.independentBuffer = IndependentBuffer()
        self.transportationResource = TransportationResource()
        self.buffer = Buffer()
        self.physicalResource = PhysicalResource()
        self.decisionMaker = DecisionMaker()

        self.transformProcess = TransformProcess()
        self.transportProcess = TransportProcess()
        self.holdingProcess = HoldingProcess()
        self.systemProcess = SystemProcess()

        self.systemConcept = SystemConcept()
        self.analytics = Analytics()
    def populateXMLData(self, xmlFilePath):
        '''
        This method reads the input XML file, instantiates an LFES object called myLFES, and populates the myLFES
        instance with its constituent data.
        :param xmlFile: Input file representing the system
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        print("I am entering populateXMLData()")
        global verboseMode; verboseMode = False
        global dataFormat; dataFormat = ''
        xmlFilePath = pl.Path(xmlFilePath)    # Convert xmlFile Path string to Path object.
        if not xmlFilePath.exists():        # Check if path to XML file exists
            print(f"XML file {pl.Path(xmlFilePath).absolute()} does not exist! Abort! Abort!")
            exit()
        else: self.inputFilePath = xmlFilePath
        _, xmlTree, _ = importXMLData(str(xmlFilePath.absolute()))  # Import all the XML Data
        # Fill the High LFES Attributes
        myRequiredKeys = {'name', 'scenario', 'refArchitecture', 'dataState', 'version','inputDataFormat','verboseMode','analyzeSoS','outputFileType'}
        appendAttributeData(self, xmlTree.attrib,myRequiredKeys)
        verboseMode = self.verboseMode[0].lower() == 'true'
        dataFormat = self.inputDataFormat[0].lower()
        self.standardizeXMLFilePath()
        self.analyzeSoS = self.analyzeSoS[0].lower() == 'true'
        if dataFormat == "default": self.populateXMLDataDefault(xmlTree)
        elif dataFormat == "capability": self.populateXMLDataCapability(xmlTree)
        else: print('dataFormat must be "default" or "capability"'); exit()
        print("I am exiting populateXMLData()")
    def produceFinalLFES(self):
        '''
        This method acts upon the myLFES instance produced by populateXMLData() and computes the HFGT mathematical
        models.
        :param myLFES: Instantiated myLFES object with HFGT meta-elements already set-up
        :return: myLFES: Complete myLFES, containing HFGT mathematical models
        '''
        print("I am entering produceFinalLFES()")
        # Extract Decision Makers
        self.extractDecisionMakers()
        # Trim Decision Makers
        self.trimDecisionMakers()
        # Calculate Operand Net Data
        self.operand.calcOperand()
        # Calculate Transformation Resource Data
        self.transformationResource.calcTransformationResource()
        # Calculate Independent Buffer Data
        self.independentBuffer.calcIndependentBuffer(self.transformationResource.number)
        # Calculate Buffers from transformation resources and independent buffer names
        self.setupBuffers()
        # Calculate Transportation Resource Data
        self.transportationResource.calcTransportationResource(self.buffer.number)
        # Calculate Resources from transformation resources, independent buffers, and transportation resource names
        self.setupPhysicalResources()
        # Calculate Decision-Maker Data
        self.decisionMaker.calcDecisionMakers()
        # Calculate Decision-Maker Adjacency Matrix
        self.decisionMaker.calcDecisionMakerAdjacency()
        # Pack Sets of System Processes
        self.packSetSystemProcess()
        # Calculate the entire system concept
        self.calcSystemConcept()
        # Calculate System-of-Systems Service Net
        if self.analyzeSoS: self.sosService = self.operand.calcSoSService()
        # Calculate Operand Feasibility Matrices
        self.calcOperandNetFeasibility()
        # Calculate Decision-Maker Agency Matrix
        self.calcDecisionMakerAgencyMatrix()
        # Calculate Mini LFES
        miniLFES= calcMiniLFES(self)
        # Serialize MiniLFES Data For Julia Processing
        outputFilePath = saveMyData(miniLFES)
        # Calculate Hetero-functional Incidence Tensors
        self.calcHeterofunctionalIncidenceTensor()
        # Calculate Hetero-functional Adjacency Matrix ARho
        self.calcHeterofunctionalAdjacencyMatrix()
        # Calculate System Adjacency Matrix
        self.calcSystemAdjacencyMatrix()
        self.dataState = ['final']
        print("I am exiting produceFinalLFES()")
    # Functions for populateXMLData()~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def standardizeXMLFilePath(self):
        if verboseMode:  print("I am entering standardizeXMLFilePath()")
        xmlFilePath = self.inputFilePath
        if (pl.Path('.git')).exists():
            self.runCode = [subprocess.check_output('git log -1 --pretty=format:"%ad" --date="short"', shell=True, text=True)]
        else:
            flag = input('Warning! Executing without Git Version Control!  Proceed?(y/n)')
            if flag.lower() == 'y': self.runCode = datetime.today().strftime('%Y-%m-%d') + '-NoGit'
            else: print("Wise Choice! Git is an essential part of computational research!"); exit()
        standardName = self.name[0] + '-' + self.inputDataFormat[0].title() + '-' +  self.scenario[0].title() + '-' +  self.runCode[0].title() + '.xml'
        if xmlFilePath.name != standardName:
            archiveTarget = (xmlFilePath.parent).joinpath('Archive/').joinpath(xmlFilePath.name)
            shutil.copy2(xmlFilePath, archiveTarget)
            standardTarget = (xmlFilePath.parent).joinpath(standardName)
            xmlFilePath.rename(standardTarget)
            self.inputFilePath = standardTarget
        if verboseMode:  print("I am exiting standardizeXMLFilePath()")
    def populateXMLDataDefault(self,xmlTree):
        if verboseMode:  print("I am entering populateXMLDataDefault()")
        if verboseMode: print(
            'Handling file with default file format ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        for xmlBranch in xmlTree:  # Loop over resource-operand layer
            if verboseMode: print('Started ', xmlBranch.tag,
                                  ' Object~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
            if xmlBranch.tag == "Operand":
                self.operand.setupOperands(xmlBranch)
            elif xmlBranch.tag == "TransformationResource":
                self.setupTransformationResources(xmlBranch)
            elif xmlBranch.tag == "IndependentBuffer":
                self.setupIndependentBuffers(xmlBranch)
            elif xmlBranch.tag == "TransportationResource":
                self.setupTransportationResources(xmlBranch)
            elif xmlBranch.tag == "DecisionMaker":
                self.decisionMaker.setupDecisionMakers(xmlBranch)
            else:
                print("The XML tag ", xmlBranch.tag, " in the Resource-Operand Layer is invalid! Abort! Abort!")
                exit()
            if verboseMode: print('Finished ', xmlBranch.tag,
                                  ' Object~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
            if verboseMode:  print("I am exiting populateXMLDataDefault()")
    def populateXMLDataCapability(self,xmlTree):
        if verboseMode:  print("I am entering populateXMLDataCapability()")
        if verboseMode: print(
            'Handling file with capability-based file format ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        for xmlBranch in xmlTree:  # Loop over flat capability layer
            if verboseMode: print('Started ', xmlBranch.tag,
                                  ' Object~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
            if xmlBranch.tag == "OperandPlace":
                self.operand.setupOperands(xmlBranch)
            elif xmlBranch.tag == "OperandTransition":
                self.operand.setupOperands(xmlBranch)
            elif xmlBranch.tag == "TransformationProcess":
                self.setupTransformationResources(xmlBranch)
            elif xmlBranch.tag == "TransportationProcess":
                if "transformationResourceName" in xmlBranch.attrib:
                    self.setupTransformationResources(xmlBranch)
                elif "independentBufferName" in xmlBranch.attrib:
                    self.setupIndependentBuffers(xmlBranch)
                elif "transportationResourceName" in xmlBranch.attrib:
                    self.setupTransportationResources(xmlBranch)
            elif xmlBranch.tag == "DecisionMaker":
                self.decisionMaker.setupDecisionMakers(xmlBranch)
            else:
                print("The XML tag ", xmlBranch.tag, " in the Resource-Operand Layer is invalid! Abort! Abort!")
                exit()
            if verboseMode: print('Finished ', xmlBranch.tag,
                                  ' Object~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if verboseMode:  print("I am exiting populateXMLDataCapability()")
    def setupTransformationResources(self, myRoot):
        '''
        This method sets up the transformation resources in the myLFES object as part of the populateXMLData() method.
        :param myRoot: An element tree object that contains the input XML file data.
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode:  print("I am entering setupTransformationResources()")
        myRequiredKeys = {'transformationResourceName','gpsX','gpsY','decisionMaker','autonomous'}
        if dataFormat == "default":
            appendAttributeData(self.transformationResource, myRoot.attrib,myRequiredKeys)
            self.transformationResource.transformProcess.append(TransformProcess())
            self.transformationResource.transportProcess.append(TransportProcess())
            self.transformationResource.name.append(self.transformationResource.transformationResourceName[-1])
            for myChild in myRoot:
                if myChild.tag == 'TransformationProcess':
                    myRequiredKeys = {'name','status','inputOperand','inputOperandWeight','outputOperand','outputOperandWeight'}
                    myChild = checkProcessWeights(myChild,'inputOperand','inputOperandWeight')
                    myChild = checkProcessWeights(myChild, 'outputOperand', 'outputOperandWeight')
                    appendAttributeData(self.transformationResource.transformProcess[-1], myChild.attrib,myRequiredKeys)
                    appendAttributeData(self.transformProcess, myChild.attrib,myRequiredKeys)
                    self.systemConcept.DOFM += 1
                elif myChild.tag == 'TransportationProcess':
                    myRequiredKeys = {'name','status','origin','destination','ref','inputOperand','inputOperandWeight','outputOperand','outputOperandWeight'}
                    myChild = checkProcessWeights(myChild,'inputOperand','inputOperandWeight')
                    myChild = checkProcessWeights(myChild, 'outputOperand', 'outputOperandWeight')
                    reviseTransportationProcessData(myChild)
                    appendAttributeData(self.transformationResource.transportProcess[-1], myChild.attrib, myRequiredKeys)
                    appendAttributeData(self.transportProcess, myChild.attrib,myRequiredKeys)
                    self.systemConcept.DOFHRef += 1
                else:
                    print("The XML tag ", myChild.tag, " in the TransformationResource Layer is invalid! Abort! Abort!")
                    exit()
            if len(self.transformationResource.transformProcess[-1].name) == 0:
                if verboseMode: print("Error!  Transformation resource ", self.transformationResource.name[-1],
                      " does not have any transformation processes! Abort! Abort")
                exit()
            if len(self.transformationResource.transportProcess[-1].name) == 0:
                if verboseMode: print("Warning!  Transformation resource ", self.transformationResource.name[-1],
                      " does not have any transportations processes! Reconsider!")
        elif dataFormat == "capability":
            if len(self.transformationResource.transformationResourceName) == 0:
                appendAttributeData(self.transformationResource, myRoot.attrib, myRequiredKeys)
                self.transformationResource.transformProcess.append(TransformProcess())
                self.transformationResource.transportProcess.append(TransportProcess())
                self.transformationResource.name[-1] = self.transformationResource.transformationResourceName[-1]
            elif myRoot.attrib["transformationResourceName"] != self.transformationResource.transformationResourceName[-1]:
                appendAttributeData(self.transformationResource, myRoot.attrib, myRequiredKeys)
                self.transformationResource.transformProcess.append(TransformProcess())
                self.transformationResource.transportProcess.append(TransportProcess())
                self.transformationResource.name[-1] = self.transformationResource.transformationResourceName[-1]
            if myRoot.tag == 'TransformationProcess':
                myRequiredKeys = {'name', 'status', 'inputOperand', 'inputOperandWeight','outputOperand','outputOperandWeight'}
                myRoot = checkProcessWeights(myRoot, 'inputOperand', 'inputOperandWeight')
                myRoot = checkProcessWeights(myRoot, 'outputOperand', 'outputOperandWeight')
                appendAttributeData(self.transformationResource.transformProcess[-1], myRoot.attrib, myRequiredKeys)
                appendAttributeData(self.transformProcess, myRoot.attrib, myRequiredKeys)
                self.systemConcept.DOFM += 1
            elif myRoot.tag == 'TransportationProcess':
                myRequiredKeys = {'name', 'status', 'origin', 'destination', 'ref', 'inputOperand', 'inputOperandWeight','outputOperand','outputOperandWeight'}
                reviseTransportationProcessData(myRoot)
                myRoot = checkProcessWeights(myRoot, 'inputOperand', 'inputOperandWeight')
                myRoot = checkProcessWeights(myRoot, 'outputOperand', 'outputOperandWeight')
                appendAttributeData(self.transformationResource.transportProcess[-1], myRoot.attrib, myRequiredKeys)
                appendAttributeData(self.transportProcess, myRoot.attrib, myRequiredKeys)
                self.systemConcept.DOFHRef += 1
            else:
                print("The XML tag ", myRoot.tag, " in the TransformationResource Layer is invalid! Abort! Abort!")
                exit()
        if verboseMode: print("I am exiting setupTransformationResources()")
    def setupIndependentBuffers(self, myRoot):
        '''
        This method sets up the independent buffers in the myLFES object as part of the populateXMLData() method.
        :param myRoot: An element tree object that contains the input XML file data.
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode:  print("I am entering setupIndependentBuffers()")
        myRequiredKeys = {'independentBufferName', 'gpsX', 'gpsY', 'decisionMaker', 'autonomous'}
        if dataFormat == "default":
            appendAttributeData(self.independentBuffer, myRoot.attrib,myRequiredKeys)
            self.independentBuffer.transportProcess.append(TransportProcess())
            self.independentBuffer.name.append(self.independentBuffer.independentBufferName[-1])
            for myChild in myRoot:
                if myChild.tag == 'TransportationProcess':
                    myRequiredKeys = {'name','status','origin','destination','ref','inputOperand','outputOperand'}
                    myChild = checkProcessWeights(myChild,'inputOperand','inputOperandWeight')
                    myChild = checkProcessWeights(myChild, 'outputOperand', 'outputOperandWeight')
                    reviseTransportationProcessData(myChild)
                    appendAttributeData(self.independentBuffer.transportProcess[-1], myChild.attrib, myRequiredKeys)
                    appendAttributeData(self.transportProcess, myChild.attrib,myRequiredKeys)
                    self.systemConcept.DOFHRef += 1
                else:
                    print("The XML tag ", myChild.tag, " in the Independent Buffer is invalid! Abort! Abort!")
                    exit()
            if len(self.independentBuffer.transportProcess[-1].name) == 0:
                print("Warning!  Independent buffer ", self.independentBuffer.name[-1],
                      " does not have any transportations processes! Reconsider!")
        elif dataFormat == "capability":
            if len(self.independentBuffer.independentBufferName) == 0:
                appendAttributeData(self.independentBuffer, myRoot.attrib, myRequiredKeys)
                self.independentBuffer.transportProcess.append(TransportProcess())
                self.independentBuffer.name[-1] = self.independentBuffer.independentBufferName[-1]
            elif myRoot.attrib["independentBufferName"] != self.independentBuffer.independentBufferName[-1]:
                appendAttributeData(self.independentBuffer, myRoot.attrib, myRequiredKeys)
                self.independentBuffer.transportProcess.append(TransportProcess())
                self.independentBuffer.name[-1] = self.independentBuffer.independentBufferName[-1]
            if myRoot.tag == 'TransportationProcess':
                myRequiredKeys = {'name', 'status', 'origin', 'destination', 'ref', 'inputOperand', 'outputOperand'}
                myRoot = checkProcessWeights(myRoot, 'inputOperand', 'inputOperandWeight')
                myRoot = checkProcessWeights(myRoot, 'outputOperand', 'outputOperandWeight')
                reviseTransportationProcessData(myRoot)
                appendAttributeData(self.independentBuffer.transportProcess[-1], myRoot.attrib, myRequiredKeys)
                appendAttributeData(self.transportProcess, myRoot.attrib, myRequiredKeys)
                self.systemConcept.DOFHRef += 1
            else:
                print("The XML tag ", myRoot.tag, " in the Independent Buffer Layer is invalid! Abort! Abort!")
                exit()
        if verboseMode:  print("I am exiting setupIndependentBuffers()")
    def setupTransportationResources(self, myRoot):
        '''
        This method sets up the transportation resources in the myLFES object as part of the populateXMLData() method.
        :param myRoot: An element tree object that contains the input XML file data.
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode: print("I am entering setupTransportationResources()")
        myRequiredKeys = {'transportationResourceName', 'decisionMaker', 'autonomous'}
        if dataFormat == "default":
            appendAttributeData(self.transportationResource, myRoot.attrib,myRequiredKeys)
            self.transportationResource.transportProcess.append(TransportProcess())
            self.transportationResource.name.append(self.transportationResource.transportationResourceName[-1])
            for myChild in myRoot:
                if myChild.tag == 'TransportationProcess':
                    myRequiredKeys = {'name', 'status', 'origin', 'destination', 'ref', 'inputOperand', 'outputOperand'}
                    myChild = checkProcessWeights(myChild,'inputOperand','inputOperandWeight')
                    myChild = checkProcessWeights(myChild, 'outputOperand', 'outputOperandWeight')
                    reviseTransportationProcessData(myChild)
                    appendAttributeData(self.transportationResource.transportProcess[-1], myChild.attrib,myRequiredKeys)
                    appendAttributeData(self.transportProcess, myChild.attrib,myRequiredKeys)
                    self.systemConcept.DOFHRef += 1
                else:
                    print("The XML tag ", myChild.tag, " in the TransformationResource Layer is invalid! Abort! Abort!")
                    exit()
            if len(self.transportationResource.transportProcess[-1].name) == 0:
                print("Error!  Transportation resource ", self.transportationResource.name[-1],
                      " does not have any transportations processes! Abort! Abort!")
                exit()
        elif dataFormat == "capability":
            if len(self.transportationResource.transportationResourceName) == 0:
                appendAttributeData(self.transportationResource, myRoot.attrib, myRequiredKeys)
                self.transportationResource.transportProcess.append(TransportProcess())
                self.transportationResource.name[-1] = self.transportationResource.transportationResourceName[-1]
            elif myRoot.attrib["transportationResourceName"] != self.transportationResource.transportationResourceName[-1]:
                appendAttributeData(self.transportationResource, myRoot.attrib, myRequiredKeys)
                self.transportationResource.transportProcess.append(TransportProcess())
                self.transportationResource.name[-1] = self.transportationResource.transportationResourceName[-1]
            if myRoot.tag == 'TransportationProcess':
                myRequiredKeys = {'name', 'status', 'origin', 'destination', 'ref', 'inputOperand', 'outputOperand'}
                myRoot = checkProcessWeights(myRoot, 'inputOperand', 'inputOperandWeight')
                myRoot = checkProcessWeights(myRoot, 'outputOperand', 'outputOperandWeight')
                reviseTransportationProcessData(myRoot)
                appendAttributeData(self.transportationResource.transportProcess[-1], myRoot.attrib, myRequiredKeys)
                appendAttributeData(self.transportProcess, myRoot.attrib, myRequiredKeys)
                self.systemConcept.DOFHRef += 1
            else:
                print("The XML tag ", myRoot.tag, " in the Independent Buffer Layer is invalid! Abort! Abort!")
                exit()
        if verboseMode:  print("I am exiting setupTransportationResources()")
    # Functions for produceFinalLFES()~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def setupBuffers(self):
        '''
        This method sets up, and collates the buffers in the myLFES object as part of the produceFinalLFES() method.
        :param : none
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode: print("I am entering setupBuffers()")
        self.buffer.name = self.transformationResource.name + self.independentBuffer.name
        self.buffer.gpsX = np.append(self.transformationResource.gpsX,self.independentBuffer.gpsX)
        self.buffer.gpsY = np.append(self.transformationResource.gpsY,self.independentBuffer.gpsY)
        self.buffer.number = self.transformationResource.number + self.independentBuffer.number
        self.buffer.autonomous = np.append(self.transformationResource.autonomous,self.independentBuffer.autonomous)
        self.buffer.decisionMaker = self.transformationResource.decisionMaker + self.independentBuffer.decisionMaker
        self.buffer.idx = np.array(range(self.buffer.number))
        self.buffer.idxBuffer = self.buffer.idx
        self.buffer.idxResource = self.buffer.idx
        self.buffer.status = np.append(self.transformationResource.status,self.independentBuffer.status)
        if verboseMode: print("I am exiting setupBuffers()")
    def setupPhysicalResources(self):
        '''
        This method sets up and collates the physical resources in the myLFES object as part of the produceFinalLFES() method.
        :param : none
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode: print("I am entering setupPhysicalResources()")
        self.physicalResource.name = self.buffer.name + self.transportationResource.name
        self.physicalResource.number = self.buffer.number + self.transportationResource.number
        self.physicalResource.decisionMaker = self.buffer.decisionMaker + self.transportationResource.decisionMaker
        self.physicalResource.autonomous = np.append(self.buffer.autonomous,self.transportationResource.autonomous)
        self.physicalResource.idx = np.array(range(self.physicalResource.number))
        self.physicalResource.idxResource = self.physicalResource.idx
        self.physicalResource.status = np.append(self.buffer.status, self.transportationResource.status)
        if verboseMode: print("I am exiting setupPhysicalResources()")
    def packSetSystemProcess(self):

        '''
        This function computes the set of all possible REFINED transportation processes in the system.
        This set of processes includes storage at a certain buffer element and transportation from one buffer
        element to all other buffer elements present in the system.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering packSetSystemProcesses()")
        # Pack Set of Transformation Processes
        if self.systemConcept.DOFM > 0:
            self.transformProcess.packSetTransformProcess(self.operand.operandName)
        else:
            print("Warning!  This LFES has no transformation capabilities!  It is a closed transportation system! Proceeding...")
            self.transformProcess = TransformProcess()
        if self.systemConcept.DOFHRef > 0:
            # Pack Set of Holding Processes
            self.holdingProcess.populateHoldingProcess(self.transportProcess)
            self.holdingProcess.packSetHoldingProcess(self.operand.operandName)
            # Pack Set of REFINED Transportation Processes
            self.transportProcess.populateTransportProcess(self.buffer, self.holdingProcess)
            self.transportProcess.packSetTransportProcess(self.holdingProcess)
        else:
            print(
                "Error! This LFES has no transportation capabilities!  Nothing stored! Nothing transported!  Abort! Abort!")
            self.holdingProcess = HoldingProcess()
            self.transportProcess = TransportProcess()
            self.transportProcess.numberMax = self.buffer.number ** 2
            self.transportProcess.numberRefMax = self.transportProcess.numberMax * self.holdingProcess.number
            exit()
        # Pack Set of System Processes
        self.transportProcess.idxProcess = self.transportProcess.idx + self.transformProcess.number
        self.systemProcess.name = self.transformProcess.name + self.transportProcess.nameRef
        self.systemProcess.idxProcess = np.concatenate((self.transformProcess.idxProcess, self.transportProcess.idxProcess))
        self.systemProcess.idx = self.systemProcess.idxProcess
        self.systemProcess.number = self.transformProcess.number + self.transportProcess.numberRef
        self.systemProcess.numberMax = self.transformProcess.number + self.transportProcess.numberRefMax
        self.systemProcess.status = np.concatenate((self.transformProcess.status, self.transportProcess.status))
        self.systemProcess.inputOperand = self.transformProcess.inputOperand + self.transportProcess.inputOperand
        self.systemProcess.inputOperandWeight = self.transformProcess.inputOperandWeight + self.transportProcess.inputOperandWeight
        self.systemProcess.outputOperand = self.transformProcess.outputOperand + self.transportProcess.outputOperand
        self.systemProcess.outputOperandWeight = self.transformProcess.outputOperandWeight + self.transportProcess.outputOperandWeight
        self.systemProcess.MLPNeg = bmat([[self.transformProcess.MLPNeg, self.transportProcess.MLPNeg]])
        self.systemProcess.MLPPos = bmat([[self.transformProcess.MLPPos, self.transportProcess.MLPPos]])
        if verboseMode: print("I am exiting packSetSystemProcesses()")
    def calcSystemConcept(self):
        '''
        This function calculates System Knowledge base JS, System Constraints Matrix KS, and System Concept AS.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering calcSystemConcept()")
        # Initialize Knowledge Bases, Constraint, and System Concept Matrices: JM, JH, JHref, KM, KH, KHref, AM, AH, AHref
        self.initializeSystemConceptMatrices()
        # Calculate Transformation Knowledge Bases: JM, KM, AM
        self.calcTransformationSystemConcept()
        # Calculate Transportation Knowledge Bases: JH, KH, AH
        self.calcTransportationSystemConcept()
        # Initialize Knowledge Bases and Constraint Tensors Updates: JHT, JHrefT, KHT, KHrefT, AHT, AHrefT
        self.initializeSystemConceptTensors()
        # Calculate Transportation Knowledge Bases Tensors: JHT, KHT, AHT
        self.calcTransportationSystemConceptTensors()
        # Calculate System Knowledge Base Sequence Independent DOF Measures Updates: DOFM, DOFH, DOFHref
        self.stackSystemConcepts()
        # Calculate the System Projection Operator
        self.systemConcept.calcProjectionOperator()
        # Calculate the Process-Capability Incidence Matrix
        self.systemConcept.calcProcessCapabilityIncidence(self.systemProcess.numberMax)
        # Calaculate the Resource-Capability Incidence Matrix
        self.systemConcept.calcResourceCapabilityIncidence(self.physicalResource.number)
        # Pack Set of Capabilities
        self.packSetCapability()
        if verboseMode: print("I am exiting calcSystemConcept")
    def initializeSystemConceptMatrices(self):
        '''
        This function initializes the knowledge bases and constraints matrices to empty
        sparse matrices of type COO (coordinate) format.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering initializeSystemConceptMatrices()")
        self.systemConcept.JM = coo_array((self.transformProcess.number, self.transformationResource.number), dtype=int)
        self.systemConcept.KM = coo_array((self.transformProcess.number, self.transformationResource.number), dtype=int)
        self.systemConcept.AM = coo_array((self.transformProcess.number, self.transformationResource.number), dtype=int)
        self.systemConcept.JG = coo_array((self.holdingProcess.number, self.physicalResource.number), dtype=int)
        self.systemConcept.KG = coo_array((self.holdingProcess.number, self.physicalResource.number), dtype=int)
        self.systemConcept.AG = coo_array((self.holdingProcess.number, self.physicalResource.number), dtype=int)
        self.systemConcept.JH = coo_array((self.transportProcess.numberMax, self.physicalResource.number), dtype=int)
        self.systemConcept.KH = coo_array((self.transportProcess.numberMax, self.physicalResource.number), dtype=int)
        self.systemConcept.AH = coo_array((self.transportProcess.numberMax, self.physicalResource.number), dtype=int)
        self.systemConcept.JHRef = coo_array((self.transportProcess.numberRefMax, self.physicalResource.number), dtype=int)
        self.systemConcept.KHRef = coo_array((self.transportProcess.numberRefMax, self.physicalResource.number), dtype=int)
        self.systemConcept.AHRef = coo_array((self.transportProcess.numberRefMax, self.physicalResource.number), dtype=int)
        if verboseMode: print("I am exiting initializeSystemConceptMatrices()")
    def initializeSystemConceptTensors(self):
        '''
        This function initializes the knowledge bases and constraints tensors to
        sparse tensors of type COO.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering initializeSystemConceptTensors()")
        self.systemConcept.JHT = COO(DOK(shape=(self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        self.systemConcept.AHT = COO(DOK(shape=(self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        self.systemConcept.KHT = COO(DOK(shape=(self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        self.systemConcept.JHRefT = COO(DOK(shape=(self.holdingProcess.number, self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        self.systemConcept.AHRefT = COO(DOK(shape=(self.holdingProcess.number, self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        self.systemConcept.KHRefT = COO(DOK(shape=(self.holdingProcess.number, self.buffer.number, self.buffer.number, self.physicalResource.number), dtype=int))
        if verboseMode: print("I am exiting initializeSystemConceptTensors()")
    def calcTransformationSystemConcept(self):
        '''
        The function calculates the Transformation Knowledge Base JM, Constraints Matrix KM,  and Transformation Concept AM.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering calcTransformationSystemConcept()")
        if self.systemConcept.DOFM > 0:
            for k in range(self.transformationResource.number):
                if isinstance(self.transformationResource.transformProcess[k], TransformProcess):
                    self.transformationResource.transformProcess[k].populateTransformProcess(self.transformProcess)
            self.systemConcept.JM = appendProcessCapabilities(self.systemConcept.JM, self.transformationResource.transformProcess, 'JM',0)
            self.systemConcept.KM = appendProcessCapabilities(self.systemConcept.KM, self.transformationResource.transformProcess, 'KM',0)

            self.systemConcept.JM = self.systemConcept.JM.todok().tocoo()
            self.systemConcept.KM = self.systemConcept.KM.todok().tocoo()

            self.systemConcept.AM = (self.systemConcept.JM - self.systemConcept.KM).tocoo()
            self.systemConcept.DOFM = self.systemConcept.AM.nnz
        if verboseMode: print("I am exiting calcTransformationSystemConcept()")
    def calcTransportationSystemConcept(self):
        '''
        This function calculates Transportation Knowledge Base JH, Constraints Matrix KH,
        and Transportation Concept AH.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering calcTransportationSystemConcept()")
        if self.systemConcept.DOFHRef > 0:
            for k in range(self.transformationResource.number):
                if isinstance(self.transformationResource.transportProcess[k], TransportProcess):
                    self.transformationResource.transportProcess[k].populateTransportProcess(self.buffer, self.holdingProcess)
            for k in range(self.independentBuffer.number):
                if isinstance(self.independentBuffer.transportProcess[k], TransportProcess):
                    self.independentBuffer.transportProcess[k].populateTransportProcess(self.buffer,self.holdingProcess)
            for k in range(self.transportationResource.number):
                if isinstance(self.transportationResource.transportProcess[k], TransportProcess):
                    self.transportationResource.transportProcess[k].populateTransportProcess(self.buffer,self.holdingProcess)

            self.systemConcept.JG = appendProcessCapabilities(self.systemConcept.JG, self.transformationResource.transportProcess, 'JG',0)
            self.systemConcept.KG = appendProcessCapabilities(self.systemConcept.KG, self.transformationResource.transportProcess, 'KG',0)
            self.systemConcept.JH = appendProcessCapabilities(self.systemConcept.JH, self.transformationResource.transportProcess, 'JH',0)
            self.systemConcept.KH = appendProcessCapabilities(self.systemConcept.KH, self.transformationResource.transportProcess, 'KH',0)
            self.systemConcept.JHRef = appendProcessCapabilities(self.systemConcept.JHRef, self.transformationResource.transportProcess, 'JHR',0)
            self.systemConcept.KHRef = appendProcessCapabilities(self.systemConcept.KHRef, self.transformationResource.transportProcess, 'KHR',0)

            self.systemConcept.JG = appendProcessCapabilities(self.systemConcept.JG, self.independentBuffer.transportProcess, 'JG',self.transformationResource.number)
            self.systemConcept.KG = appendProcessCapabilities(self.systemConcept.KG, self.independentBuffer.transportProcess, 'KG',self.transformationResource.number)
            self.systemConcept.JH = appendProcessCapabilities(self.systemConcept.JH, self.independentBuffer.transportProcess, 'JH',self.transformationResource.number)
            self.systemConcept.KH = appendProcessCapabilities(self.systemConcept.KH, self.independentBuffer.transportProcess, 'KH',self.transformationResource.number)
            self.systemConcept.JHRef = appendProcessCapabilities(self.systemConcept.JHRef, self.independentBuffer.transportProcess, 'JHR',self.transformationResource.number)
            self.systemConcept.KHRef = appendProcessCapabilities(self.systemConcept.KHRef, self.independentBuffer.transportProcess, 'KHR',self.transformationResource.number)

            self.systemConcept.JG = appendProcessCapabilities(self.systemConcept.JG, self.transportationResource.transportProcess, 'JG',self.buffer.number)
            self.systemConcept.KG = appendProcessCapabilities(self.systemConcept.KG, self.transportationResource.transportProcess, 'KG',self.buffer.number)
            self.systemConcept.JH = appendProcessCapabilities(self.systemConcept.JH, self.transportationResource.transportProcess, 'JH',self.buffer.number)
            self.systemConcept.KH = appendProcessCapabilities(self.systemConcept.KH, self.transportationResource.transportProcess, 'KH',self.buffer.number)
            self.systemConcept.JHRef = appendProcessCapabilities(self.systemConcept.JHRef, self.transportationResource.transportProcess, 'JHR',self.buffer.number)
            self.systemConcept.KHRef = appendProcessCapabilities(self.systemConcept.KHRef, self.transportationResource.transportProcess, 'KHR',self.buffer.number)

            self.systemConcept.JG = self.systemConcept.JG.todok().tocoo()
            self.systemConcept.KG = self.systemConcept.KG.todok().tocoo()
            self.systemConcept.JH = self.systemConcept.JH.todok().tocoo()
            self.systemConcept.KH = self.systemConcept.KH.todok().tocoo()
            self.systemConcept.JHRef = self.systemConcept.JHRef.todok().tocoo()
            self.systemConcept.KHRef = self.systemConcept.KHRef.todok().tocoo()

            self.systemConcept.AG = (self.systemConcept.JG - self.systemConcept.KG).tocoo()
            self.systemConcept.AH = (self.systemConcept.JH - self.systemConcept.KH).tocoo()
            self.systemConcept.AHRef = (self.systemConcept.JHRef - self.systemConcept.KHRef).tocoo()
            self.systemConcept.DOFG = self.systemConcept.AG.nnz
            self.systemConcept.DOFH = self.systemConcept.AH.nnz
            self.systemConcept.DOFHRef = self.systemConcept.AHRef.nnz

            temp = (COO.from_scipy_sparse(self.systemConcept.AH)).sum(1)
            self.systemConcept.ABS  = ivecMat(temp, [self.buffer.number, self.buffer.number])
            temp = (COO.from_scipy_sparse(self.systemConcept.AHRef)).sum(1)
            self.systemConcept.ALBS = ivecMat(temp, [self.buffer.number,self.buffer.number,self.holdingProcess.number])
        if verboseMode: print("I am exiting calcTransportationSystemConcept()")
    def calcTransportationSystemConceptTensors(self):
        '''
        This function calculates Transportation Knowledge Base, Constraints, and Concept Tensors.
        It also calculates the refined transportation knowledge base, constraints, and concept tensors.
        :param myLFES:
        :return:
        '''
        if verboseMode: print('I am entering calcTransportationSystemConceptTensors()')
        self.systemConcept.JHT = tensorize(self.systemConcept.JH,
                                          [self.buffer.number, self.buffer.number, self.physicalResource.number], [1, 0], [2])
        self.systemConcept.KHT = tensorize(self.systemConcept.KH,
                                          [self.buffer.number, self.buffer.number, self.physicalResource.number], [1, 0], [2])
        self.systemConcept.AHT = self.systemConcept.JHT - self.systemConcept.KHT

        self.systemConcept.JHRefT = tensorize(self.systemConcept.JHRef,
                                             [self.holdingProcess.number, self.buffer.number, self.buffer.number,
                                              self.physicalResource.number], [2, 1, 0], [3])
        self.systemConcept.KHRefT = tensorize(self.systemConcept.KHRef,
                                             [self.holdingProcess.number, self.buffer.number, self.buffer.number,
                                              self.physicalResource.number], [2, 1, 0], [3])
        self.systemConcept.AHRefT = self.systemConcept.JHRefT - self.systemConcept.KHRefT
        if verboseMode: print('I am exiting calcTransportationSystemConceptTensors()')
    def stackSystemConcepts(self):
        '''
        This function identifies all of the system capabilities.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering stackSystemConcepts()")
        self.systemConcept.JS = vstack([hstack([self.systemConcept.JM, csc_array(
            (self.transformProcess.number, self.independentBuffer.number + self.transportationResource.number),
            dtype=int)]), self.systemConcept.JHRef], format='coo')
        self.systemConcept.KS = vstack([hstack([self.systemConcept.KM, csc_array(
            (self.transformProcess.number, self.independentBuffer.number + self.transportationResource.number),
            dtype=int)]), self.systemConcept.KHRef], format='coo')
        self.systemConcept.AS = vstack([hstack([self.systemConcept.AM, csc_array(
            (self.transformProcess.number, self.independentBuffer.number + self.transportationResource.number),
            dtype=int)]), self.systemConcept.AHRef], format='coo')
        self.systemConcept.AS = self.systemConcept.AS.tocoo()

        # Make sure to fix the order of the encoded I,J,V data of the System Concept Matrix.
        idx = np.argsort(self.systemConcept.AS.shape[0] * (self.systemConcept.AS.col) + self.systemConcept.AS.row)
        self.systemConcept.AS.col = self.systemConcept.AS.col[idx]
        self.systemConcept.AS.row = self.systemConcept.AS.row[idx]
        self.systemConcept.AS.data = self.systemConcept.AS.data[idx]

        self.systemConcept.DOFS = self.systemConcept.DOFM + self.systemConcept.DOFHRef
        self.systemConcept.DOFMax = self.systemProcess.numberMax * self.physicalResource.number
        if verboseMode: print("I am exiting stackSystemConcepts()")
    def packSetCapability(self):
        '''
        This function identifies all of the system capabilities.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering packSetCapability()")
        self.systemConcept.idxPsiCapability = np.array(range(self.systemConcept.DOFS))
        self.systemConcept.idxChiCapability = self.systemConcept.PS.col
        self.systemConcept.idxResource = self.systemConcept.AS.col
        self.systemConcept.idxProcess = self.systemConcept.AS.row
        self.systemConcept.idxOperand = self.systemProcess.MLPNeg.dot(self.systemConcept.PPS).tocoo()
        self.systemConcept.idxOutput = self.systemProcess.MLPPos.dot(self.systemConcept.PPS).tocoo()
        self.systemConcept.name = [self.physicalResource.name[self.systemConcept.AS.col[idxPsi]] + ' ' +
                                self.systemProcess.name[list(self.systemProcess.idx).index(self.systemConcept.AS.row[idxPsi])]
                                for idxPsi in range(self.systemConcept.DOFS)]
        if self.analyzeSoS:
            self.systemConcept.nameSoS = self.systemConcept.name + ['LFES initiate SoSService', 'LFES finish SoSService']
        if verboseMode: print("I am exiting packSetCapability()")
    def calcOperandNetFeasibility(self):
        '''
        This function calculates the service feasibility matrix. It uses the DOFs to find
        the services performed by the DOFs.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering calcOperandFeasibility()")
        for k1 in range(len(self.operand.operandNet)):
            if isinstance(self.operand.operandNet[k1],OperandNet):
                if verboseMode: print('Operand: ', self.operand.operandName[k1], 'Operand Net: ', self.operand.operandNet[k1].operandNetName)
                myOperandNet = self.operand.operandNet[k1]
                myOperandNet.calcTransformationFeasibilityMatrix(self.transformProcess)
                myOperandNet.calcHoldingFeasibilityMatrix(self.holdingProcess)
                myOperandNet.LambdaTransport = kron(myOperandNet.LambdaHolding, np.ones([1, self.transportProcess.numberMax]), 'coo')
                myOperandNet.Lambda = (hstack([myOperandNet.LambdaTransform, myOperandNet.LambdaTransport])).tocoo()
                myOperandNet.syncMat = myOperandNet.Lambda.dot(self.systemConcept.PPS).tocoo()
                self.operand.operandNet[k1] = myOperandNet
                if verboseMode: print('Finished Operand Net', self.operand.operandNet[k1].operandNetName)
        # Calculate ALrho - System Operand Synchronization Matrix
        self.operand.calcSystemOperandSyncMatrix()
        if self.analyzeSoS and isinstance(self.sosService.operandNet, OperandNet):
            if verboseMode: print('Operand: ', self.sosService.name, 'Operand Net: ', self.sosService.operandNet.name)
            myOperandNet = self.sosService.operandNet
            myOperandNet.calcTransformationFeasibilityMatrix(self.transformProcess)
            myOperandNet.calcHoldingFeasibilityMatrix(self.holdingProcess)
            myOperandNet.LambdaTransport = kron(myOperandNet.LambdaHolding,np.ones([1, self.transportProcess.numberMax]), 'coo')
            myOperandNet.LambdaSoS = calcIncidenceMatrix(myOperandNet.operandTransition.processLinkName,['initiate SoSService', 'finish SoSService'], 'row')
            myOperandNet.Lambda = (hstack([myOperandNet.LambdaTransform, myOperandNet.LambdaTransport,myOperandNet.LambdaSoS])).tocsc()
            newPPS = bmat([[self.systemConcept.PPS, None],[None, eye(2)]])
            myOperandNet.syncMat = myOperandNet.Lambda.dot(newPPS).tocoo()
            self.sosService.operandNet = myOperandNet
            if verboseMode: print('Finished Operand Net', self.sosService.operandNet.name)
        if verboseMode: print("I am exiting calcOperandFeasibility()")
    def calcDecisionMakerAgencyMatrix(self):
        '''
        This method calculates the Decision Maker Agency Matrix in the myLFES object as part of the produceFinalLFES() method.
        :param : none
        :return: myLFES: An instantiated Large Flexible Engineering System object ready to compute HFGT mathematical models
        '''
        if verboseMode:  print("I am entering calcDecisionMakerAgencyMatrix()")
        myRows = self.physicalResource.decisionMaker
        myCols = self.decisionMaker.name
        self.decisionMaker.A_RD = calcIncidenceMatrix(self.physicalResource.decisionMaker, self.decisionMaker.name,
                                                      'row')
        # Calculate ADrho - System DecisionMaker Agency Matrix
        tempMat = tileSparseMatrix(self.decisionMaker.A_RD, self.systemProcess.numberMax,'col')
        self.decisionMaker.ARhoD = self.systemConcept.PS.dot(tempMat).tocoo()
        if verboseMode:  print("I am exiting calcDecisionMakerAgencyMatrix()")
    def calcHeterofunctionalIncidenceTensor(self):
        '''
        This function calculates the positive and negative hetero-functional incidence tensors.
        :param self:
        :return:
        '''
        if verboseMode:  print("I am entering calcHeterofunctionalIncidenceTensor()")
        self.calcHeterofunctionalIncidenceTensorNeg()
        self.calcHeterofunctionalIncidenceTensorPos()
        self.analytics.MRho2 = (self.analytics.MRho2Pos - self.analytics.MRho2Neg).tocoo()
        self.analytics.MRho3 = self.analytics.MRho3Pos - self.analytics.MRho3Neg
        self.analytics.MPR4  = self.analytics.MPR4Pos - self.analytics.MPR4Neg
        if verboseMode:  print("I am exiting calcHeterofunctionalIncidenceTensor()")
    def calcHeterofunctionalIncidenceTensorNeg(self):
        """
        This function computes the projected and un-projected forms of the
        negative hetero-functional incidence tensor as well as the 4th order tensor.
        :param self:
        :return:
        """
        if verboseMode: print("I am entering calcHeterofunctionalIncidenceTensorNeg()")
        self.analytics.MRho3Neg = DOK((self.operand.number, self.buffer.number, self.systemConcept.DOFS), dtype=int)
        self.analytics.MPR4Neg = DOK((self.operand.number, self.buffer.number, self.systemProcess.numberMax, self.physicalResource.number),
            dtype=int)
        # self.analytics.MPR3Neg = DOK((self.operand.number, self.buffer.number, self.systemProcess.number * self.physicalResource.number), dtype=int)
        idxL = [];
        idxBS = [];
        idxPsi = [];
        idxVals = []
        for i in range(self.operand.number):
            for y1 in range(self.buffer.number):
                if verboseMode: startTime = time.time()
                # profiler = cProfile.Profile()
                # profiler.enable()
                # Compute Xiy1minus, vectorize it and apply projection operator
                PXiy1minusV = projectVecSystemConcept(vecMAT(calcXiy1minus(i, y1, self)),self.systemConcept)
                # temp = PXiy1minusV.toarray()
                # profiler.disable()
                # stats = pstats.Stats(profiler)
                # stats.sort_stats('cumulative').print_stats(10)  # Print top 10 functions by cumulative time
                if verboseMode: print('Total computation time taken: %f' % (time.time() - startTime))
                idxL.extend([i] * PXiy1minusV.nnz)
                idxBS.extend([y1] * PXiy1minusV.nnz)
                idxPsi.extend(PXiy1minusV.row)
                idxVals.extend([1] * PXiy1minusV.nnz)
        idxP, idxR, idxChi = resolvePsiCapabilityIndex(idxPsi, self.systemConcept)
        self.analytics.MPR4Neg[idxL, idxBS, idxP, idxR] = idxVals
        self.analytics.MRho3Neg[idxL, idxBS, idxPsi] = idxVals
        self.analytics.MPR4Neg = COO(self.analytics.MPR4Neg)
        self.analytics.MRho3Neg = COO(self.analytics.MRho3Neg)
        self.analytics.MRho2Neg = matricize(self.analytics.MRho3Neg, [1, 0], [2])
        if verboseMode: print("I am exiting calcHeterofunctionalIncidenceTensorNeg()")
    def calcHeterofunctionalIncidenceTensorPos(self):
        """
        This function computes the projected and un-projected forms of the
        negative hetero-functional incidence tensor as well as the 4th order tensor.
        :param self:
        :return:
        """
        if verboseMode: print("I am entering calcHeterofunctionalIncidenceTensorPos()")
        self.analytics.MRho3Pos = DOK((self.operand.number, self.buffer.number, self.systemConcept.DOFS), dtype=int)
        self.analytics.MPR4Pos  = DOK((self.operand.number, self.buffer.number, self.systemProcess.numberMax, self.physicalResource.number), dtype=int)
        idxL    = []; idxBS   = []; idxPsi  = []; idxVals = []
        for i in range(self.operand.number):
            for y2 in range(self.buffer.number):
                # Compute Xiy2plus, vectorize it and apply projection operator
                PXiy2plusV = projectVecSystemConcept(vecMAT(calcXiy2plus(i, y2, self)),self.systemConcept)
                idxL.extend([i]*PXiy2plusV.nnz)
                idxBS.extend([y2]*PXiy2plusV.nnz)
                idxPsi.extend(PXiy2plusV.row)
                idxVals.extend([1]*PXiy2plusV.nnz)
        idxP, idxR, idxChi = resolvePsiCapabilityIndex(idxPsi, self.systemConcept)
        self.analytics.MPR4Pos[idxL, idxBS, idxP, idxR] = idxVals
        self.analytics.MRho3Pos[idxL,idxBS,idxPsi] = idxVals
        self.analytics.MPR4Pos = COO(self.analytics.MPR4Pos)
        self.analytics.MRho3Pos = COO(self.analytics.MRho3Pos)
        self.analytics.MRho2Pos = matricize(self.analytics.MRho3Pos,[1,0],[2])
        if verboseMode: print("I am exiting calcHeterofunctionalIncidenceTensorPos()")
    def calcHeterofunctionalAdjacencyMatrix(self):
        """
        This function computes the projected and un-projected forms of the
        negative hetero-functional incidence tensor as well as the 4th order tensor.
        :param self:
        :return:
        """
        if verboseMode: print("I am entering calcHeterofunctionalAdjacencyMatrix()")
        self.analytics.ARho = (self.analytics.MRho2Pos.T.dot(self.analytics.MRho2Neg)).tocoo()
        self.analytics.APR = coo_array((self.systemConcept.DOFMax, self.systemConcept.DOFMax), dtype=int)
        self.analytics.APR.row = self.systemConcept.idxChiCapability[self.analytics.ARho.row]
        self.analytics.APR.col = self.systemConcept.idxChiCapability[self.analytics.ARho.col]
        self.analytics.APR.data = self.analytics.ARho.data
        self.analytics.APR4 = tensorize(self.analytics.APR,
                                        [self.systemProcess.numberMax,self.physicalResource.number,
                                         self.systemProcess.numberMax,self.physicalResource.number],[0,1],[2,3])

        self.analytics.AFormal = (self.analytics.MRho2Neg.dot(self.analytics.MRho2Pos.T)).tocoo()
        self.analytics.AFormalT = tensorize(self.analytics.AFormal,
                        [self.operand.number, self.buffer.number, self.operand.number,
                        self.buffer.number], [0,1], [2,3])
        if self.analyzeSoS:
            idxSource = np.isin(np.array(self.operand.sosType),'source')
            idxSource = ((self.systemConcept.idxOperand.todok()[idxSource,:]).sum(axis=0).astype(bool).astype(int))[np.newaxis]

            idxMustProduce = np.isin(np.array(self.operand.sosType),'must produce')
            idxMustProduce = (((self.systemConcept.idxOutput.todok()[idxMustProduce,:]).sum(axis=0).astype(bool).astype(int))[np.newaxis]).T

            self.analytics.ARhoSoS = bmat([[self.analytics.ARho, np.zeros((self.systemConcept.DOFS, 1)), idxMustProduce],
                         [idxSource, None, None],[np.zeros((1, self.systemConcept.DOFS)), None, None]])
        if verboseMode: print("I am exiting calcHeterofunctionalAdjacencyMatrix()")
    def calcSystemAdjacencyMatrix(self):
        '''
        This function calculates the system adjacency matrix
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering calcSystemAdjacencyMatrix()")
        A1 = [self.operand.AL, self.operand.ALrho, None]
        A2 = [self.operand.ALrho.transpose(), self.analytics.ARho, self.decisionMaker.ARhoD]
        A3 = [None, self.decisionMaker.ARhoD.transpose(), self.decisionMaker.A_DD]
        self.analytics.ASys = bmat([A1, A2, A3])
        if verboseMode: print("I am exiting calcSystemAdjacencyMatrix()")

    # Functions for exportFinalLFES()~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class SystemConcept():
    def __init__(self):
        self.name = []
        self.nameSoS = []
        self.idxPsiCapability = 0
        self.idxChiCapability = 0
        self.idxResource = 0
        self.idxProcess = 0
        self.idxOperand = 0
        self.idxOutput = 0
        self.DOFM = 0
        self.DOFHRef = 0
        self.DOFG = 0
        self.DOFH = 0
        self.DOFS = 0
        self.JM = 0
        self.KM = 0
        self.AM = 0
        self.JH = 0
        self.KH = 0
        self.AH = 0
        self.JG = 0
        self.KG = 0
        self.AG = 0
        self.JHRef = 0
        self.KHRef = 0
        self.AHRef = 0
        self.JS = 0
        self.KS = 0
        self.AS = 0
        self.JHT = 0
        self.KHT = 0
        self.AHT = 0
        self.JHRefT = 0
        self.KHRefT = 0
        self.AHRefT = 0
        self.PS = 0
        self.PPS = 0
        self.PRS = 0
    def calcProjectionOperator(self):
        if verboseMode: print("I am entering calcProjectionOperator()")
        self.PS = coo_array((self.DOFS, self.DOFMax), dtype=int)
        self.PS.col = (vecMAT(self.AS)).row
        self.PS.row = range(len(self.PS.col))
        self.PS.data = np.repeat(1, len(self.PS.col))
        if verboseMode: print("I am exiting calcProjectionOperator()")
    def calcProcessCapabilityIncidence(self, numProcesses):
        if verboseMode: print("I am entering calcProcessCapabilityIncidence")
        self.PPS = coo_array((numProcesses, self.DOFS), dtype=int)
        self.PPS.row = self.AS.row
        self.PPS.col = range(len(self.PPS.row))
        self.PPS.data = np.repeat(1, len(self.PPS.row))
        if verboseMode: print("I am exiting calcProcessCapabilityIncidence")
    def calcResourceCapabilityIncidence(self, numResources):
        if verboseMode: print("I am entering calcResourceCapabilityIncidence")
        self.PRS = coo_array((numResources, self.DOFS), dtype=int)
        self.PRS.row = self.AS.col
        self.PRS.col = range(len(self.PRS.row))
        self.PRS.data = np.repeat(1, len(self.PRS.row))
        if verboseMode: print("I am exiting calcResourceCapabilityIncidence")
class Analytics():
    def __init__(self):
        self.MPR4Neg = []
        self.MRho3Neg = []
        self.MRho2Neg = []
        self.MPR4Pos = []
        self.MRho3Pos = []
        self.MRho2Pos = []
        self.MPR4 = []
        self.MRho3 = []
        self.MRho2 = []

        self.ARho = []
        self.APR = []
        self.APR4 = []
        self.ARhoSoS = []
        self.AFormal = []
        self.AFormalT = []
        self.ASys = []
## Operands ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Operand():
    def __init__(self):
        self.idx =[]
        self.operandName = []
        self.operandNet = []
        self.number = []
        self.sosType = []
        self.operandType = []
        self.AL = []
        self.ALrho = []
    def setupOperands(self, myRoot):
        if verboseMode:  print("I am entering setupOperands()")
        myRequiredKeys = {'operandName', 'operandType'}
        if dataFormat == "default":
            appendAttributeData(self, myRoot.attrib, myRequiredKeys)
            for myChild in myRoot:
                if myChild.tag == 'OperandNet':  # You need some ORs for OperandPlace and OperandTransition
                    self.setupOperandNets(myChild)
                else:
                    print("The XML tag ", myChild.tag, " in the OperandNet Layer is invalid! Abort! Abort!")
                    exit()
            if myRoot.find('OperandNet') == None:
                print('Warning! Operand ', self.operandName[-1], ' does not have an operand net. Proceeding ...')
                self.operandNet.append(GenericClass())
            self.number = len(self.operandName)
            if self.number == 0:
                print("Error!  ALL LFESs must have at least one operand!  Abort! Abort!")
                exit()
        elif dataFormat == "capability":
            if len(self.operandName) == 0: appendAttributeData(self, myRoot.attrib, myRequiredKeys)
            elif myRoot.attrib["operandName"] != self.operandName[-1]: appendAttributeData(self, myRoot.attrib, myRequiredKeys)
            self.setupOperandNets(myRoot)
        else:
            print("Error!  LFES Data Format is invalid! Abort! Abort!")
            exit()
        if verboseMode:  print("I am exiting setupOperands()")
    def setupOperandNets(self, myRoot):
        '''
        This function copies the attributes of myProcesses associated with a resource from the intermediary
        :param opt: “M”,“C”, or “H” for transformation process, control process,
            or transportation process respectively
        :return:
        '''
        if verboseMode:  print("I am entering setupOperandNets()")
        myRequiredKeys = {'operandNetName', 'status'}
        if dataFormat == "default":
            myOperandNet = OperandNet()
            appendAttributeData(myOperandNet, myRoot.attrib, myRequiredKeys)
            for myChild in myRoot:
                if myChild.tag == 'OperandPlace':
                    myRequiredKeys = {'name', 'type'}
                    appendAttributeData(myOperandNet.operandPlace, myChild.attrib, myRequiredKeys)
                elif myChild.tag == 'OperandTransition':
                    myRequiredKeys = {'name', 'preset', 'postset', 'processLinkName', 'processLinkRef'}
                    appendAttributeData(myOperandNet.operandTransition, myChild.attrib, myRequiredKeys)
                else:
                    print("The XML tag ", myChild.tag, " in the OperandNet Layer is invalid! Abort! Abort!")
                    exit()
            myOperandNet.operandNetName = myOperandNet.operandNetName[0]
            self.operandNet.append(myOperandNet)
        elif dataFormat == "capability":
            if not self.operandNet or myRoot.attrib["operandNetName"] != self.operandNet[-1].operandNetName:
                myOperandNet = OperandNet()
                appendAttributeData(myOperandNet, myRoot.attrib, myRequiredKeys)
            else:
                myOperandNet = self.operandNet[-1]
            if myRoot.tag == 'OperandPlace':
                myRequiredKeys = {'name', 'type'}
                appendAttributeData(myOperandNet.operandPlace, myRoot.attrib, myRequiredKeys)
            elif myRoot.tag == 'OperandTransition':
                myRequiredKeys = {'name', 'preset', 'postset', 'processLinkName', 'processLinkRef'}
                appendAttributeData(myOperandNet.operandTransition, myRoot.attrib, myRequiredKeys)
            else:
                print("The XML tag ", myRoot.tag, " in the OperandNet Layer is invalid! Abort! Abort!")
                exit()
            if not self.operandNet or myRoot.attrib["operandNetName"] != self.operandNet[-1].operandNetName:
                myOperandNet.operandNetName = myOperandNet.operandNetName[0]
                self.operandNet.append(myOperandNet)
            else:
                self.operandNet[-1] = myOperandNet
        if verboseMode:  print("I am exiting setupOperandNets()")
    def calcOperand(self):
        if verboseMode: print("I am entering calcOperand()")
        self.number = len(self.operandName)
        self.idx = np.array(range(self.number))
        for k in range(len(self.operandNet)): #myOperandNet in self.operandNet:
            myOperandNet = self.operandNet[k]
            if isinstance(myOperandNet, OperandNet):
                if len(myOperandNet.operandPlace.name) == 0:
                    print("Error!  Operand Net ", myOperandNet.operandNetName, " does not have any places!  Abort! Abort!")
                    exit()
                if len(myOperandNet.operandTransition.name) == 0:
                    if dataFormat == "capability" and len(myOperandNet.operandPlace.name) == 1:
                        myOperandNet = GenericClass()
                        self.operandNet[k] = GenericClass()
                    elif dataFormat == "capability" and len(myOperandNet.operandPlace.name) > 1:
                        print("Error!  Operand Net ", myOperandNet.operandNetName,
                              " does not have any transitions but has multpile places!  Exiting!")
                        exit()
                    else:
                        print("Error!  Operand Net ", myOperandNet.operandNetName, " does not have any transitions!  Exiting!")
                        exit()
            else:
                print('Warning!  Operand ', self.operandName[k], ' does not have an operand net. Proceeding ...')
            if isinstance(myOperandNet, OperandNet):
                if any(np.isin(np.array(myOperandNet.operandPlace.type), 'source')): self.sosType.append('source')
                elif any(np.isin(np.array(myOperandNet.operandPlace.type), 'must produce')): self.sosType.append('must produce')
                elif any(np.isin(np.array(myOperandNet.operandPlace.type), 'sink')): self.sosType.append('sink')
                else: self.sosType.append('internal')
                # Calculate Operand Net Incidence Matrix
                myOperandNet.calcOperandIncidenceMatrix()
                # Calculate Operand Net Adjacency Matrix
                myOperandNet.calcOperandAdjacencyMatrix()
                # Note that there is no need to copy myOperandNet back in because myOperand is a reference and not a deepcopy.
        # Calculate AL -- System Operand Graph
        self.calcSystemOperandGraph()
        if verboseMode: print("I am exiting calcOperand()")
    def calcSoSService(self):
        if verboseMode:  print("I am entering calcSoSService()")
        mySoSService = self.collectAllOperands()
        mySoSService.operandNet.consolidateOperandNet()
        if verboseMode: print("I am exiting calcSoSService()")
        return mySoSService
    def collectAllOperands(self):
        if verboseMode: print("I am entering collectAllOperands()")
        myOperandNet = OperandNet()
        myOperandNet.operandNetName = 'deliver SoS service'
        myOperandNet.number = 1
        myOperandNet.status = ['true']
        # Collect data from all individual operands
        for k in range(self.number):
            myOperandNet.operandPlace.name.extend(self.operandNet[k].operandPlace.name)
            myOperandNet.operandPlace.type.extend(self.operandNet[k].operandPlace.type)
            for k1 in range(len(self.operandNet[k].operandTransition.name)):
                # Use the holding process name if it is linked to a refined transportation process
                if self.operandNet[k].operandTransition.processLinkName[k1].startswith('transport') or self.operandNet[k].operandTransition.processLinkName[k1].startswith('transport'):
                    myOperandNet.operandTransition.name.append(self.operandNet[k].operandTransition.processLinkRef[k1])
                # Use the processing name if it is a transformation process.
                else:
                    myOperandNet.operandTransition.name.append(self.operandNet[k].operandTransition.processLinkName[k1])
            myOperandNet.operandTransition.preset.extend(self.operandNet[k].operandTransition.preset)
            myOperandNet.operandTransition.postset.extend(self.operandNet[k].operandTransition.postset)
            myOperandNet.operandTransition.processLinkName.extend(self.operandNet[k].operandTransition.processLinkName)
            myOperandNet.operandTransition.processLinkRef.extend(self.operandNet[k].operandTransition.processLinkRef)
        mySoSService = Operand()
        mySoSService.operandNetName = 'deliver SoS service'
        mySoSService.operandName = 'SoS service'
        mySoSService.idx = 0
        mySoSService.sosType = 'hybrid'
        mySoSService.operandNet = myOperandNet
        mySoSService.number = 1
        if verboseMode:  print("I am exiting collectAllOperands()")
        return mySoSService
    def calcSystemOperandGraph(self):
        if verboseMode: print("I am entering calcSystemOperandGraph()")
        tempList = []
        for myOperandNet in self.operandNet:
            if isinstance(myOperandNet, OperandNet): tempList.append(myOperandNet.Adual)
            else: tempList.append(coo_array((0, 0), dtype=int))
        tempList = tuple(tempList)
        if len(tempList) > 0: self.AL = block_diag(tuple(tempList))
        else:  self.AL = coo_array((0, 0), dtype=int)
        if verboseMode:  print("I am exiting calcSystemOperandGraph()")
    def calcSystemOperandSyncMatrix(self):
        tempList = []
        for myOperandNet in self.operandNet:
            if isinstance(myOperandNet, OperandNet): tempList.append(myOperandNet.syncMat)
            else: tempList.append(coo_array((0, 0), dtype=int))
        self.ALrho = vstack(tempList)
class OperandNet():
    def __init__(self):
        self.operandNetName = []
        self.number = 1
        self.status = []
        self.Aprime = []
        self.Adual = []
        self.LambdaTransform = []
        self.LambdaHolding = []
        self.LambdaTransport = []
        self.Lambda = []
        self.syncMat = []
        self.Mneg = []
        self.Mpos = []
        self.operandPlace = OperandPlace()
        self.operandTransition = OperandTransition()
    def calcOperandIncidenceMatrix(self):
        if verboseMode: print("I am entering calcOperandIncidenceMatrix()")
        self.Mneg = calcIncidenceMatrix(self.operandPlace.name,self.operandTransition.preset,'col')
        self.Mpos = calcIncidenceMatrix(self.operandPlace.name,self.operandTransition.postset,'col')
        if verboseMode: print("I am exiting calcOperandIncidenceMatrix()")
    def calcOperandAdjacencyMatrix(self):
        if verboseMode: print("I am entering calcOperandAdjacencyMatrix()")
        self.Aprime = (self.Mneg.dot(self.Mpos.T)).tocoo()
        self.Adual  = ((self.Mpos.T).dot(self.Mneg)).tocoo()
        if verboseMode: print("I am exiting calcOperandAdjacencyMatrix()")
    def consolidateOperandNet(self):
        if verboseMode: print("I am entering consolidateOperandNet()")
        myTransitionNames, idxSet, idxList = np.unique(self.operandTransition.name, return_index=True, return_inverse=True)
        self.operandTransition.name = list(myTransitionNames)
        # The penultimate operand net transition is the initiating transition
        # The last operand net transition is the finalizing transition.
        self.operandTransition.name.extend(['initiate SoSService','finish SoSService'])
        self.operandTransition.processLinkName = list(np.array(self.operandTransition.processLinkName)[idxSet])
        self.operandTransition.processLinkName.extend(['initiate SoSService','finish SoSService'])
        self.operandTransition.processLinkRef = list(np.array(self.operandTransition.processLinkRef)[idxSet])
        self.operandTransition.processLinkRef.extend(['',''])
        myPresets  = [''] * len(idxSet)
        myPostsets = [''] * len(idxSet)
        for k in range(len(idxList)):
            # Only add a comma if you need to
            if myPresets[idxList[k]] != '' and self.operandTransition.preset[k] != '': myPresets[idxList[k]] = myPresets[idxList[k]] + ','
            if myPostsets[idxList[k]] != '' and self.operandTransition.postset[k] != '': myPostsets[idxList[k]] += ','
            # Append what you find in presets and postsets
            myPresets[idxList[k]] = myPresets[idxList[k]] + self.operandTransition.preset[k]
            myPostsets[idxList[k]] = myPostsets[idxList[k]] + self.operandTransition.postset[k]
        idxTemp = np.isin(self.operandPlace.type,'source')
        temp = ','.join(np.array(self.operandPlace.name)[idxTemp])
        myPostsets.extend([temp,''])
        idxTemp = np.isin(self.operandPlace.type,'must produce')
        temp = ','.join(np.array(self.operandPlace.name)[idxTemp])
        myPresets.extend(['',temp])
        self.operandTransition.preset = myPresets
        self.operandTransition.postset = myPostsets
        self.calcOperandIncidenceMatrix()
        self.calcOperandAdjacencyMatrix()
        if verboseMode: print("I am exiting consolidateOperandNet()")
    def calcTransformationFeasibilityMatrix(self, myTransformProcesses):
        if verboseMode: print("I am entering calcTransformationFeasibilityMatrix()")
        self.LambdaTransform = calcIncidenceMatrix(self.operandTransition.processLinkName, myTransformProcesses.name, 'row')
        if verboseMode: print("I am exiting calcTransformationFeasibilityMatrix()")
    def calcHoldingFeasibilityMatrix(self, myHoldingProcesses):
        if verboseMode: print("I am entering calcHoldingFeasibilityMatrix()")
        self.LambdaHolding = calcIncidenceMatrix(self.operandTransition.processLinkRef, myHoldingProcesses.name, 'row')
        if verboseMode: print("I am exiting calcHoldingFeasibilityMatrix()")
class OperandPlace():
    def __init__(self):
        self.name = []
        self.type = []
class OperandTransition():
    def __init__(self):
        self.name = []
        self.preset = []
        self.postset = []
        self.processLinkName = []
        self.processLinkRef = []
## RESOURCES~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class Resource():
    def __init__(self):
        self.name = []
        self.idx = []
        self.number = []
        self.status = []
class PhysicalResource():
    def __init__(self):
        Resource.__init__(self)
        self.idxResource = []
        self.decisionMaker = []
        self.autonomous = []
class Buffer():
    def __init__(self):
        PhysicalResource.__init__(self)
        self.idxBuffer = []
        self.gpsX = []
        self.gpsY = []
class TransformationResource():
    def __init__(self):
        Buffer.__init__(self)
        self.transformationResourceName = []
        self.transformProcess = []
        self.transportProcess = []
    def calcTransformationResource(self):
        if verboseMode:  print("I am entering calcTransformationResource()")
        self.number = len(self.name)
        self.idx = np.array(range(self.number))
        self.gpsX = np.array(self.gpsX, dtype=float)
        self.gpsY = np.array(self.gpsY, dtype=float)
        self.idxBuffer = self.idx
        self.idxResource = self.idx
        self.autonomous = np.array([myItem.lower() == 'true' for myItem in self.autonomous])
        self.status = np.ones(self.number, dtype=bool)
        if self.number == 0:
            print("Warning!  This LFES has no transformation resources. It is a closed transportation system!")
        if verboseMode:  print("I am exiting calcTransformationResource()")
class IndependentBuffer():
    def __init__(self):
        Buffer.__init__(self)
        self.independentBufferName = []
        self.transportProcess = []
    def calcIndependentBuffer(self, numTransformationResources):
        if verboseMode:  print("I am entering calcIndependentBuffer()")
        self.number = len(self.name)
        self.idx = np.array(range(self.number))
        self.gpsX = np.array(self.gpsX, dtype=float)
        self.gpsY = np.array(self.gpsY, dtype=float)
        self.idxBuffer = numTransformationResources + self.idx
        self.idxResource = self.idxBuffer
        self.autonomous = np.array([myItem.lower() == 'true' for myItem in self.autonomous])
        self.status = np.ones(self.number, dtype=bool)
        if self.number == 0:
            print("Warning! This LFES has no independent buffers. Some transformation process happens everywhere! Proceeding...")
        if verboseMode:  print("I am exiting calcIndependentBuffer()")
class TransportationResource():
    def __init__(self):
        PhysicalResource.__init__(self)
        self.transportationResourceName = []
        self.transportProcess = []
    def calcTransportationResource(self, numBuffers):
        if verboseMode:  print("I am entering calcTransportationResource()")
        self.number = len(self.name)
        self.idx = np.array(range(self.number))
        self.idxResource = numBuffers + self.idx
        self.autonomous = np.array([myItem.lower() == 'true' for myItem in self.autonomous])
        self.status = np.ones(self.number, dtype=bool)
        if self.number == 0:
            print("Warning!  This LFES has no transportation resources.  "
                  "Are all transportation processes handled by buffers? Proceeding...")
        if verboseMode:  print("I am exiting calcTransportationResource()")
class DecisionMaker():
    def __init__(self):
        Resource.__init__(self)
        self.peerRecipient = []
        self.A_DD = []
        self.A_RD = []
        self.ARhoD = []
    def setupDecisionMakers(self, myRoot):
        if verboseMode:  print("I am entering setupDecisionMakers()")
        myRequiredKeys = {'name','status','peerRecipient'}
        appendAttributeData(self, myRoot,myRequiredKeys)
        if verboseMode: print("I am exiting setupDecisionMakers()")
    def calcDecisionMakers(self):
        if verboseMode:  print("I am entering calcDecisionMakers()")
        self.number = len(self.name)
        self.idx = np.array(range(self.number))
        self.status = np.array([myItem.lower() == 'true' for myItem in self.status])
        if verboseMode:  print("I am entering calcDecisionMakers()")
    def calcDecisionMakerAdjacency(self):
        if verboseMode:  print("I am entering calcDecisionMakerAdjacency()")
        self.A_DD = calcIncidenceMatrix(self.name,self.peerRecipient,'col')
        if verboseMode:  print("I am exiting calcDecisionMakerAdjacency()")
## PROCESS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class SystemProcess():
    def __init__(self):
        self.name = []
        self.idx = []
        self.idxProcess = []
        self.status =[]
        self.inputOperand = []
        self.inputOperandWeight = []
        self.outputOperand = []
        self.outputOperandWeight = []
        self.MLPNeg = []
        self.MLPPos = []
        self.number = []
        self.numberMax = []
class TransformProcess():
    def __init__(self):
        SystemProcess.__init__(self)
    def packSetTransformProcess(self, myOperands):
        '''
        This function packs the set of transformation processes with numpy unique.
        It also calculates the number of transformation processes.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering packSetTransformProcess()")
        indices = np.unique(self.name, return_index=True)[1]
        self.name = [self.name[index] for index in sorted(indices)]
        self.inputOperand = [self.inputOperand[index] for index in sorted(indices)]
        self.inputOperandWeight = [self.inputOperandWeight[index] for index in sorted(indices)]
        self.outputOperand = [self.outputOperand[index] for index in sorted(indices)]
        self.outputOperandWeight = [self.outputOperandWeight[index] for index in sorted(indices)]
        self.number = len(self.name)
        self.numberMax = self.number
        self.idx = np.array(range(self.number))
        self.idxProcess = self.idx
        self.status = [self.status[index] for index in sorted(indices)]
        self.status = np.array([myItem.lower() == 'true' for myItem in self.status])
        self.MLPNeg = calcIncidenceMatrix(myOperands, self.inputOperand, 'col',self.inputOperandWeight)
        self.MLPPos = calcIncidenceMatrix(myOperands, self.outputOperand, 'col',self.outputOperandWeight)
        if verboseMode: print("I am exiting packSetTransformProcess()")
    def populateTransformProcess(self, myTransformProcessList):
        '''
        This function populates the data attributes of an instance of the TransformProcess class.
        :param myTransformProcess, myTransformProcess
        :return: myTransformProcess
        '''
        if verboseMode: print("I am entering populateTransformProcessData()")
        self.number = len(self.name)
        self.numberMax = self.number
        self.idx = np.array((np.isin(myTransformProcessList.name, self.name)).nonzero()).flatten()
        self.status = (np.array([myItem.lower() == 'true' for myItem in self.status]))
        if verboseMode: print("I am exiting populateTransformProcessData()")
class HoldingProcess():
    def __init__(self):
        SystemProcess.__init__(self)
    def populateHoldingProcess(self,myTransportProcesses):
        if verboseMode: print("I am entering populateHoldingProcess()")
        self.name = myTransportProcesses.ref
        self.inputOperand = myTransportProcesses.inputOperand
        self.inputOperandWeight = myTransportProcesses.inputOperandWeight
        self.outputOperand = myTransportProcesses.outputOperand
        self.outputOperandWeight = myTransportProcesses.outputOperandWeight
        self.status = myTransportProcesses.status
        if verboseMode: print("I am exiting populateHoldingProcess()")
    def packSetHoldingProcess(self,myOperands):
        '''
        This function makes all possible refined transportation processes from an myLFES.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering packSetHoldingProcess()")
        idxList = np.unique(self.name, return_index=True)[1]
        self.name = [self.name[k] for k in sorted(idxList)]
        self.inputOperand = [self.inputOperand[k] for k in sorted(idxList)]
        self.inputOperandWeight = [self.inputOperandWeight[k] for k in sorted(idxList)]
        self.outputOperand = [self.outputOperand[k] for k in sorted(idxList)]
        self.outputOperandWeight = [self.outputOperandWeight[k] for k in sorted(idxList)]
        self.number = len(self.name)
        self.idx = np.array(range(self.number))
        self.idxProcess = []
        self.status = [self.status[k] for k in sorted(idxList)]
        self.status = np.array([myItem.lower() == 'true' for myItem in self.status])
        self.MLPNeg = calcIncidenceMatrix(myOperands, self.inputOperand, 'col',self.inputOperandWeight)
        self.MLPPos = calcIncidenceMatrix(myOperands, self.outputOperand, 'col',self.outputOperandWeight)
        if verboseMode: print("I am exiting packSetHoldingProcess()")
class TransportProcess():
    def __init__(self):
        SystemProcess.__init__(self)
        self.origin = []
        self.destination = []
        self.ref = []
        self.nameRef = []
        # self.statusRef = []
        self.idxOrigin = []
        self.idxDestination = []
        self.idxHolding = []
        self.idxTransport = []
        self.numberRefMax = []
    def populateTransportProcess(self, myBuffer, myHoldingProcess):
        '''
        This function populates the data attributes of an instance of the TransportProcess class.
        :param myTransportProcess, myBuffer, myHoldingProcess
        :return: myTransportProcess
        '''
        if verboseMode: print("I am entering populateTransportProcessData()")
        for k in range(len(self.name)):
            if self.origin[k].lower() == self.destination[k].lower():
                temp = self.name[k].lower()
                self.name[k] = temp.replace('transport', 'store')
        self.number = len(self.name)
        self.numberRef = len(self.nameRef)
        self.numberMax = myBuffer.number ** 2
        self.numberRefMax = self.numberMax * myHoldingProcess.number
        self.status = np.array([myItem.lower() == 'true' for myItem in self.status])
        # self.statusRef = np.array([myItem.lower() == 'true' for myItem in self.statusRef])
        self.idxOrigin = np.array([myBuffer.name.index(self.origin[k]) for k in range(self.number)])
        self.idxDestination = np.array([myBuffer.name.index(self.destination[k]) for k in range(self.number)])
        self.idxHolding = np.array([myHoldingProcess.name.index(self.ref[k]) for k in range(self.number)])
        self.getIdxTransportProcess(myBuffer.number)
        self.getIdxTransportProcessRef()
        if verboseMode: print("I am exiting populateTransportProcessData()")
    def getIdxTransportProcess(self, numBuffers):
        '''
        This function calculates the transportation process index.
        :param idxOrigin: origin index
        :param idxDestination: destination index
        :param numBuffers: number of buffers
        :return:
        '''
        self.idxTransport = numBuffers * (self.idxOrigin) + self.idxDestination
    def getIdxTransportProcessRef(self):
        '''
        This function calculates the refined transportation process index.
        :param idxTransport: index of process within the set of transportation processes
        :param idxHolding: holding process index
        :param numTransportProcess:
        :return: refined transportation process index
        '''
        self.idx = self.numberMax * (self.idxHolding) + self.idxTransport
    def packSetTransportProcess(self,myHoldingProcess):
        '''
        This function computes the set of all possible REFINED transportation processes in the system.
        This set of processes includes storage at a certain buffer element and transportation from one buffer
        element to all other buffer elements present in the system.
        :param myLFES:
        :return:
        '''
        if verboseMode: print("I am entering packSetTransportProcesses()")
        idxList = np.unique(self.nameRef, return_index=True)[1]
        self.name = [self.name[k] for k in sorted(idxList)]
        self.nameRef = [self.nameRef[k] for k in sorted(idxList)]
        self.number = len(self.name)
        self.numberRef = len(self.nameRef)
        self.origin = [self.origin[k] for k in sorted(idxList)]
        self.destination = [self.destination[k] for k in sorted(idxList)]
        self.inputOperand = [self.inputOperand[k] for k in sorted(idxList)]
        self.inputOperandWeight = [self.inputOperandWeight[k] for k in sorted(idxList)]
        self.outputOperand = [self.outputOperand[k] for k in sorted(idxList)]
        self.outputOperandWeight = [self.outputOperandWeight[k] for k in sorted(idxList)]
        self.ref = [self.ref[k] for k in sorted(idxList)]
        self.status = np.array([self.status[k] for k in sorted(idxList)])
        self.idxDestination = np.array([self.idxDestination[k] for k in sorted(idxList)])
        self.idxHolding = np.array([self.idxHolding[k] for k in sorted(idxList)])
        self.idxOrigin = np.array([self.idxOrigin[k] for k in sorted(idxList)])
        self.idxTransport = np.array([self.idxTransport[k] for k in sorted(idxList)])
        self.idx = np.array([self.idx[k] for k in sorted(idxList)])
        self.MLPNeg = kron(myHoldingProcess.MLPNeg, np.ones([1, self.numberMax]), 'coo')
        self.MLPPos = kron(myHoldingProcess.MLPPos, np.ones([1, self.numberMax]), 'coo')
        if verboseMode: print("I am exiting packSetTransportProcesses()")
class GenericClass():
    pass
## UTILITY FUNCTIONS ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def importXMLData(xmlfile):
    '''
    This function reads in an XML file and outputs a Tuple with three elements.
    The first element is the tree, the second one is the root, the third is
    the tags.
    :param xmlfile: Input XML file
    :return: tree : myLFES object details
             root : Intermediary structure to feed myLFES object
             tags : myLFES meta-elements
    '''
    print("I am entering importXMLData()")
    tree = ET.parse(xmlfile)
    root = tree.getroot()
    tags = list({child.tag for child in root})
    print("I am exiting importXMLData()")
    return tree, root, tags
def checkProcessWeights(myChild,stringKey,weightStringKey):
    myChildKeys = set(myChild.attrib.keys())
    myRequiredKeys = {stringKey,weightStringKey}
    if not (myChildKeys.issuperset(myRequiredKeys)):
        print('The following required keys are missing:', myRequiredKeys.difference(myChildKeys), 'in ',myChild.attrib[list(myChild.attrib.keys())[0]], '.  Abort! Abort!')
        exit()
    operandStrings = re.split(r',\s*', myChild.attrib[stringKey])
    if myChild.attrib[stringKey] == '':     #Process has no input/output operand
        myChild.attrib[weightStringKey] = np.array([])
    else:                                   #Process has an input/output operand
        if myChild.attrib[weightStringKey] == '':   #Input/Output operand weight is empty
            myChild.attrib[weightStringKey] = np.ones(len(operandStrings))
        else:                                       #Input/Output operand weight is not empty
            inputOperandWeightStrings = re.split(r',\s*', myChild.attrib[weightStringKey])
            if len(operandStrings) == len(inputOperandWeightStrings):
                myChild.attrib[weightStringKey] = np.array([float(x) for x in inputOperandWeightStrings])
            else:
                print('Error! ' + myChild.attrib['name'] + ' does not have an equal number of ' + stringKey + ' and ' + weightStringKey + '! Abort! Abort!')
                exit()
    return myChild
def appendAttributeData(myObj, myRoot,myRequiredKeys):
    '''
        This function inserts values from a dictionary to an object
        if the object has a variable with the same name as that of a key in the dictionary
        :param objectA: object being filled in
        :param dictB: dictionary with desired value
        :return:
        '''
    if verboseMode:  print("I am entering appendAttributeData()")
    myRootKeys = set(myRoot.keys())
    myObjKeys = set(myObj.__dict__.keys())
    if not (myRootKeys.issuperset(myRequiredKeys)):             # Check if all the required keys are in the data...
        print('The following required keys are missing:', myRequiredKeys.difference(myRootKeys), 'in ', myRoot[list(myRoot.keys())[0]],'.  Abort! Abort!')
        exit()
    missingKeys = myRootKeys.difference(myObjKeys)
    if len(missingKeys) > 0:                                    # Check if the object has all of keys in the data...
        for key in missingKeys: setattr(myObj,key, [])
    myRootKeys = list(myRoot.keys())
    listLength = len(getattr(myObj,myRootKeys[0]))
    for item in myRootKeys:
        if len(getattr(myObj,item)) != listLength:              # Check if the attributes in myObj are the correct length
            getattr(myObj, item).extend([''] * (listLength - len(getattr(myObj,item))))
    for key, value in myRoot.items():
        if isinstance(value,str) and value == '':
            if verboseMode:
                if isinstance(myObj,TransformationResource):
                    print(
                        'Warning! Atttribute value is empty in ' + key + ' key in ' + str(type(myObj)) + ' named ' +
                        myRoot['transformationResourceName'])
                elif isinstance(myObj,IndependentBuffer):
                    print(
                        'Warning! Atttribute value is empty in ' + key + ' key in ' + str(type(myObj)) + ' named ' +
                        myRoot['independentBufferName'])
                elif isinstance(myObj,TransportationResource):
                    print(
                        'Warning! Atttribute value is empty in ' + key + ' key in ' + str(type(myObj)) + ' named ' +
                        myRoot['transportationResourceName'])
                else:
                    print('Warning! Atttribute value is empty in ' + key + ' key in ' + str(type(myObj)) + ' named ' + myRoot['name'])
        getattr(myObj, key).append(value)
    if verboseMode:  print("I am exiting appendAttributeData()")
def reviseTransportationProcessData(myRoot):
    if verboseMode: print("I am entering reviseTransportationProcessData()")
    if 'store' in myRoot.attrib['name'].lower():
        myRoot.attrib['name'] = myRoot.attrib['name'].lower() + ' @ ' + myRoot.attrib['origin']
        myRoot.attrib['nameRef'] = myRoot.attrib['name'].lower() + ' while ' + myRoot.attrib['ref']
    elif 'transport' in myRoot.attrib['name'].lower():
        myRoot.attrib['name'] = myRoot.attrib['name'].lower() + ' f. ' + myRoot.attrib['origin'] + ' t. ' + \
                                myRoot.attrib['destination']
        myRoot.attrib['nameRef'] = myRoot.attrib['name'].lower() + ' while ' + myRoot.attrib['ref']
    else:
        print("Transportation process ", myRoot.attrib['name'],
              " improperly written. Begin with transport or store [operand]")
        exit()
    # myRoot.attrib['statusRef'] = myRoot.attrib['status']
    if verboseMode:  print("I am exiting reviseTransportationProcessData()")
def tensorize(AMatrix, tensorSize, idxRow, idxCol):
    if verboseMode: print('I am entering tensorize()')
    # This code accepts any 2D numpy or sparse array.
    # It does not accept a list of lists.
    # IT forces computation on a full numpy array or COO.
    if issparse(AMatrix):
      if not isinstance(AMatrix, COO):
        if verboseMode: print("Converting matrix to sparse.COO()")
        if isinstance(AMatrix, DOK): AMatrix = COO(AMatrix)
        else:  AMatrix = COO.from_scipy_sparse(AMatrix)
    rowSize = np.array([tensorSize[k] for k in idxRow])
    colSize = np.array([tensorSize[k] for k in idxCol])
    tensorSize = (np.concatenate((rowSize,colSize))).tolist()
    idx = (np.concatenate((idxRow,idxCol))).tolist()
    # reshapeMAT(A,R,C) is the MATLAB equivalent of reshape(A,R,C).
    # ipermute(A,R,C) works just like its MATLAB equivalent
    ATensor = permute(reshapeMAT(AMatrix, tensorSize), idx)
    if verboseMode: print('I am exiting tensorize()')
    return ATensor
def matricize(ATensor, idxRow, idxCol):
    if verboseMode: print("I am entering matricize()")
    # This code accepts any higher order (3+) numpy or sparse array.
    # It does not accept a list of lists.
    # IT forces computation on a full numpy array or COO.
    if issparse(ATensor):
      if not isinstance(ATensor, COO):
        if verboseMode: print("Converting matrix to sparse.COO()")
        if isinstance(ATensor, DOK): ATensor = COO(AMTensor)
        else:  ATensor = COO.from_scipy_sparse(ATensor)
    tensorSize = list(ATensor.shape)
    rowSize = [np.prod([tensorSize[i] for i in idxRow])]
    colSize = [np.prod([tensorSize[i] for i in idxCol])]
    idx = (np.concatenate((idxRow,idxCol))).tolist()
    matSize = (np.concatenate((rowSize,colSize))).tolist()
    # reshapeMAT(A,R,C) is the MATLAB equivalent of reshape(A,R,C).
    # permute(A,R,C) works just like its MATLAB equivalent
    AMatrix = reshapeMAT(permute(ATensor,idx),matSize)
    if verboseMode: print("I am exiting matricize()")
    return AMatrix
def reshapeMAT(AMatrix,myDims):  # This is the MATLAB equivalent of reshape()
    # This code accepts any numpy or sparse array.
    # It does not accept a list of lists.
    # IT forces computation on a full numpy array or COO.
    if isinstance(AMatrix,list):
      print("Invalid input.  Convert list to matrix first!")
      exit()
    if issparse(AMatrix):
      if not isinstance(AMatrix, COO):
        if verboseMode: print("Converting matrix to sparse.COO()")
        if isinstance(AMatrix, DOK): AMatrix = COO(AMatrix)
        else:  AMatrix = COO.from_scipy_sparse(AMatrix)
    myResult = AMatrix.T.reshape(myDims[::-1]).T
    if isinstance(myResult, COO) & (len(myDims) <= 2): myResult = coo_array(COO.to_scipy_sparse(myResult))
    return myResult
def permute(ATensor,myDims):        # This is the MATLAB equivalent of permute()
    # This code accepts any numpy or sparse array.
    # It must test for the type to accomodate the slight difference in syntax
    if issparse(ATensor): myResult = ATensor.transpose(axes=myDims)
    else:  myResult = ATensor.transpose(myDims)
    return myResult
def ivecMat(AVector,myDims):
    if AVector.ndim != 1:
      print("Not a vector! Length equal to ", len(AVector))
      exit()
    if isinstance(AVector, list):
        AVector = np.array(AVector)
    return reshapeMAT(AVector, myDims)
def vecMAT(AMatrix):
    if verboseMode: print("I am entering vecMAT()")
    myDim = [np.prod(AMatrix.shape)]
    myResult = AMatrix.reshape((myDim[0],1),order='F')
    if verboseMode: print("I am exiting vecMAT()")
    return myResult
def calcIncidenceMatrix(rowList, colList,opt,myWeights=True):
    if verboseMode: print("I am entering calcIncidenceMatrix()")
    if opt == 'col':
        if verboseMode: print("Looping over columns...")
    elif opt == 'row':
        if verboseMode: print("Looping over rows...")
        temp = rowList; rowList = colList; colList = temp
    else: print("Invalid option for calcIncidenceMatrix()!!! Abort! Abort! Option is either col or row"); exit()
    myMatrix = coo_array((len(rowList), len(colList)), dtype=int)
    for k in range(len(colList)):
        myColListStrings = re.split(r',\s*', colList[k])
        idx = np.array((np.isin(rowList, myColListStrings)).nonzero()).flatten()
        extraStringList = np.setdiff1d(myColListStrings, np.append(rowList,''))
        if len(extraStringList) > 0:
            if verboseMode: print('Warning!  There are extra strings in the test string array:  ', extraStringList)
        myMatrix.row = np.append(myMatrix.row, idx)
        myMatrix.col = np.append(myMatrix.col, np.repeat(k, len(idx)))
        if myWeights == True: myMatrix.data = np.append(myMatrix.data, np.repeat(1, len(idx)))
        else:
            if len(idx) == len(myWeights[k]): myMatrix.data = np.append(myMatrix.data, myWeights[k])
            else:
                print('The ' + str(k) + '_th array in the weights list does not have the right size')
    if opt == 'row':
        myMatrix = myMatrix.T
    if verboseMode: print("I am exiting calcIncidenceMatrix()")
    return myMatrix
def appendProcessCapabilities(sparseMat, myProcesses, opt,idxShift):
    if verboseMode: print("I am entering appendCapabilities()")
    for k in range(len(myProcesses)):
        idxResource = k + idxShift
        if isinstance(myProcesses[k], TransformProcess):
            # if verboseMode: print('k:', k, 'Opt:', opt, len(myProcesses))
            if opt == 'JM': idxProcess  = myProcesses[k].idx
            elif opt == 'KM':
                if len(myProcesses[k].status) > 0: idxProcess  = myProcesses[k].idx[~myProcesses[k].status]
                else: idxProcess = []
            else: print("Please provide an option:  JM, or KM"); exit()
        elif isinstance(myProcesses[k], TransportProcess):
            # if verboseMode: print('k:', k, 'Opt:', opt, len(myProcesses))
            if opt == 'JG':
                idxProcess  = myProcesses[k].idxHolding
            elif opt == 'KG':
                if len(myProcesses[k].status) > 0: idxProcess  = myProcesses[k].idxHolding[~myProcesses[k].status]
                else: idxProcess = []
            elif opt == 'JH': idxProcess  = myProcesses[k].idxTransport
            elif opt == 'KH':
                if len(myProcesses[k].status) > 0: idxProcess  = myProcesses[k].idxTransport[~myProcesses[k].status]
                else: idxProcess = []
            elif opt == 'JHR': idxProcess = myProcesses[k].idx
            elif opt == 'KHR':
                if len(myProcesses[k].status) > 0: idxProcess = myProcesses[k].idx[~myProcesses[k].status]
                else: idxProcess = []
            else: print("Please provide an option:  JG, KG, JH, KH, JHR, or KHR"); exit()
        else: idxProcess = []
        sparseMat.row  = np.append(sparseMat.row, idxProcess)
        sparseMat.col  = np.append(sparseMat.col, np.repeat(idxResource, len(idxProcess)))
        sparseMat.data = np.append(sparseMat.data, np.repeat(1, len(idxProcess)))
    if verboseMode: print("I am exiting appendCapabilities()")
    return sparseMat
def getElVec(k, n):
    x = dok_array((n,1), dtype=int)
    if 0 <= k and k < n: x[k] = True
    return x.tocsc()
def calcXiy1minus(i, y1, myLFES):
    if verboseMode: print("I am entering calcXiy1minus()")
    MLPNegMU = myLFES.transformProcess.MLPNeg.tocsc()
    MLPNegG  = myLFES.holdingProcess.MLPNeg.tocsc()
    e_i_L    = getElVec(i,myLFES.operand.number)
    e_y1_M   = getElVec(y1,myLFES.transformationResource.number)
    e_y1_BS  = getElVec(y1,myLFES.buffer.number)

    A1 = (MLPNegMU.T).dot(e_i_L.dot(e_y1_M.T))
    A2 = coo_array((myLFES.transformProcess.number, myLFES.physicalResource.number - myLFES.transformationResource.number), dtype=bool)
    A = hstack((A1, A2))
    B1 = (MLPNegG.T).dot(e_i_L)
    B2 = kron(e_y1_BS, np.array([[True] * myLFES.buffer.number]).T)
    B  = kron(B1,kron(B2,np.array([[True] * myLFES.physicalResource.number])),'coo')
    xiy1minus = vstack((A, B))
    if verboseMode: print("I am exiting calcXiy1minus()")
    return xiy1minus
def calcXiy2plus(i, y2, myLFES):
    if verboseMode: print("I am entering calcXiy2plus()")
    MLPPosMU = myLFES.transformProcess.MLPPos.tocsc()
    MLPPosG  = myLFES.holdingProcess.MLPPos.tocsc()
    e_i_L    = getElVec(i,myLFES.operand.number)
    e_y2_M   = getElVec(y2,myLFES.transformationResource.number)
    e_y2_BS  = getElVec(y2,myLFES.buffer.number)

    A1 = (MLPPosMU.T).dot(e_i_L.dot(e_y2_M.T))
    A2 = coo_array((myLFES.transformProcess.number, myLFES.physicalResource.number - myLFES.transformationResource.number), dtype=bool)
    A = hstack((A1, A2))
    B1 = (MLPPosG.T).dot(e_i_L)
    B2 = kron(np.array([[True] * myLFES.buffer.number]).T,e_y2_BS)
    B  = kron(B1,kron(B2,np.array([[True] * myLFES.physicalResource.number])),'coo')
    xiy2plus = vstack((A, B))
    if verboseMode: print("I am exiting calcXiy1minus()")
    return xiy2plus
def projectVecSystemConcept(AVector, mySystemConcept):
    if verboseMode: print("I am entering projectVecSystemConcept()")
    myResult = coo_array((mySystemConcept.DOFS,1), dtype=np.float64)
    # idx = np.isin(AVector.row, mySystemConcept.idxChiCapability,kind='table')  # Check which rows match
    idx = isin_numba_set(mySystemConcept.idxChiCapability,AVector.row)
    myResult.row = mySystemConcept.idxPsiCapability[idx]
    myResult.col = np.zeros(len(myResult.row))
    myResult.data = np.ones(len(myResult.row))
    if verboseMode: print("I am exiting projectVecSystemConcept()")
    return myResult
def resolvePsiCapabilityIndex(idxPsi, systemConcept):
    if verboseMode: print("I am entering resolvePsiCapabilityIndex()")
    idxProcess  = systemConcept.idxProcess[idxPsi].tolist()
    idxResource = systemConcept.idxResource[idxPsi].tolist()
    idxChi      = systemConcept.idxChiCapability[idxPsi].tolist()
    if verboseMode: print("I am exiting resolvePsiCapabilityIndex())")
    return idxProcess, idxResource, idxChi
def calcMiniLFES(self):
    miniLFES = GenericClass()
    miniLFES.outputDirectory = self.outputDirectory
    miniLFES.outputFileType = self.outputFileType
    miniLFES.outputDataFormat = ["mini"]
    miniLFES.MLPNegMU = self.transformProcess.MLPNeg
    miniLFES.MLPNegG  = self.holdingProcess.MLPNeg
    miniLFES.numOperands  = self.operand.number
    miniLFES.numTransformationResource = self.transformationResource.number
    miniLFES.numTransformProcess = self.transformProcess.number
    miniLFES.numBuffer = self.buffer.number
    miniLFES.numPhysicalResource = self.physicalResource.number
    miniLFES.name = self.name
    miniLFES.inputDataFormat = self.inputDataFormat
    miniLFES.scenario = self.scenario
    miniLFES.runCode = self.runCode
    miniLFES.idxChiCapability = self.systemConcept.idxChiCapability
    return miniLFES
def saveMyData(inputData,*args):
    print("I am entering saveMyData().")
    outputData = copy.deepcopy(inputData)
    outputData = dictify(outputData)
    if len(args) > 0:   # If the optional inputs are provided they are processed..
        outputDirectory = pl.Path(args[0])
        outputFileName = args[1]
        outputFileType = args[2]
    else:               # Otherwise, they are drawn from myData
        if isinstance(outputData['outputDirectory'], list): outputDirectory = pl.Path(outputData['outputDirectory'][0])
        else: outputDirectory = pl.Path(outputData['outputDirectory'])
        if 'name' in outputData and 'inputDataFormat' in outputData and 'scenario' in outputData and 'runCode' in outputData:
            outputFileName = 'myLFES-' + outputData['outputDataFormat'][0].title() + '-'+  outputData['name'][0] + '-' + \
                            outputData['inputDataFormat'][0].title() + '-' + outputData['scenario'][0].title() + '-' + \
                            outputData['runCode'][0].title()
        else:
            print("The output data does not have a name, inputDataFormat, scenario, and runCode. Please specify!")
            myName = input('Name:')
            myInputDataFormat = input('InputDataFormat:')
            myScenario = input('Scenario:')
            myRunCode = input('RunCode:')
            outputFileName = 'myLFES-' + myName + '-' + myInputDataFormat + '-' + myScenario + '-' + myRunCode
        if isinstance(outputData['outputFileType'], list): outputFileType = outputData['outputFileType'][0]
        else: outputFileType = outputData['outputFileType']
    outputDirectory.mkdir(parents=True, exist_ok=True)
    if outputFileType.lower() == 'json' or True:
        outputFilePath = outputDirectory.joinpath(outputFileName + '.json')
        outputJSON = open(outputFilePath, 'w')
        json.dump(outputData, outputJSON)
        outputJSON.close()
        print('Success! Output file exported to ', str(outputFilePath))
    if outputFileType.lower() == 'xml' or outputFileType.lower() == 'all':
        print('Warning!  The XML exporter is one way only! At present, there is no XML import functionality!...')
        outputFilePath = outputDirectory.joinpath(outputFileName + '.xml')
        xml = dicttoxml(outputData, custom_root="myLFES", attr_type = False)
        xml = xml.decode()
        xmlFID= open(outputFilePath, "w")
        xmlFID.write(xml)
        xmlFID.close()
        print('Success! Output file exported to ', str(outputFilePath))
    if outputFileType.lower() == 'bsdf' or outputFileType.lower() == 'all':
        outputFilePath = outputDirectory.joinpath(outputFileName + '.bsdf')
        bsdf.save(str(outputFilePath), outputData)
        print('Success! Output file exported to ', str(outputFilePath))
    if outputFileType.lower() == 'mat' or outputFileType.lower() == 'all':
        outputFilePath = outputDirectory.joinpath(outputFileName + '.mat')
        _ = octave.addpath('./src_octave')
        octave.saveOctaveFile(str(outputFilePath), outputData, "-v7", nout=0)  # saves a version 7 MAT file of the outputData
        print('Success! Output file exported to ', str(outputFilePath))
    if outputFileType.lower() == 'hdf5' or outputFileType.lower() == 'all':
        outputFilePath = outputDirectory.joinpath(outputFileName + '.hdf5')
        # EXPERIMENTAL _ = octave.addpath('./src_octave')
        # EXPERIMENTAL octave.saveOctaveFile(str(outputFilePath), outputData, "-hdf5", nout=0)  # saves a HDF5 of the outputData
        print('Success! Output file exported to ', str(outputFilePath))
    if outputFileType.lower() == 'csv' or outputFileType.lower() == 'all':
        outputDirectory = outputDirectory.joinpath('CSVs/myLFES')
        outputDirectory.mkdir(parents=True, exist_ok=True)
        outputFileSuffix = re.split("^[a-zA-Z]*-", (outputFileName + '.csv'), 1)[1]
        saveMatrixToCSV(inputData, outputDirectory, outputFileSuffix)
        print('Success! Output files exported to ', str(outputDirectory.parent))
    print("I am exiting saveMyData()")
    return str(outputFilePath)
def saveMatrixToCSV(outputData, outputDirectory, outputFileSuffix):
    if isinstance(outputData, dict):
        outputKeys = list(outputData.keys())
        for k in range(len(outputKeys)):
            if outputData[outputKeys[k]] is None: pass
            elif isinstance(outputData[outputKeys[k]], (str,int,bool,float,pl.PosixPath,np.ndarray,np.int64,np.dtypes.Int64DType)): pass
            elif isinstance(outputData[outputKeys[k]], (list,tuple)):
                if len(outputData[outputKeys[k]]) > 0 \
                        and not isinstance(outputData[outputKeys[k]][0], (str,int,bool,float,pl.PosixPath,np.ndarray,np.int64,np.dtypes.Int64DType)):
                    newOutputDirectory = outputDirectory.joinpath(outputKeys[k])
                    newOutputDirectory.mkdir(parents=True, exist_ok=True)
                    for k1 in range(len(outputData[outputKeys[k]])):
                        tempOutputDirectory = newOutputDirectory.joinpath(str(k1))
                        saveMatrixToCSV(outputData[outputKeys[k]][k1], tempOutputDirectory, outputFileSuffix)
                else: pass
            elif isinstance(outputData[outputKeys[k]], dict):
                newOutputDirectory = outputDirectory.joinpath(outputKeys[k])
                newOutputDirectory.mkdir(parents=True, exist_ok=True)
                saveMatrixToCSV(outputData[outputKeys[k]], newOutputDirectory, outputFileSuffix)
                del outputData[outputKeys[k]]
                if len(os.listdir(newOutputDirectory))==0: os.rmdir(newOutputDirectory)
            else:
                newOutputDirectory = outputDirectory.joinpath(outputKeys[k])
                newOutputDirectory.mkdir(parents=True, exist_ok=True)
                saveMatrixToCSV(outputData[outputKeys[k]], newOutputDirectory, outputFileSuffix)
                del outputData[outputKeys[k]]
                if len(os.listdir(newOutputDirectory))==0: os.rmdir(newOutputDirectory)
        outputFilePath = str(outputDirectory) + '-' + outputFileSuffix
        with open(outputFilePath, 'w') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=outputKeys)
            writer.writeheader()
            writer.writerows([outputData])
    elif isinstance(outputData, coo_array):
        myHeader = 'idxRow-' + str(outputData.shape[0]) + ',idxCol-' + str(outputData.shape[1]) + ',value'
        myCSVMatrix = (np.array([outputData.row, outputData.col, outputData.data])).T
        outputFilePath = str(outputDirectory) + '-' + outputFileSuffix
        np.savetxt(outputFilePath, myCSVMatrix, delimiter=',', header=myHeader, comments='')
    elif isinstance(outputData, COO):
        myHeader = ''
        for k in range(outputData.ndim):
            myHeader = myHeader + 'idxDim' + str(k) + '-' + str(outputData.shape[k]) + ','
        myHeader = myHeader + 'value'
        myCSVMatrix = (np.vstack((outputData.coords,outputData.data))).T
        outputFilePath = str(outputDirectory) + '-' + outputFileSuffix
        np.savetxt(outputFilePath, myCSVMatrix, delimiter=',', header=myHeader, comments='')
    else:
        outputData = outputData.__dict__
        saveMatrixToCSV(outputData, outputDirectory, outputFileSuffix)
def loadMyData(inputFilePath):
    sniffer = 0
    print("I am entering loadMyData().")
    inputFilePath = pl.Path(inputFilePath)
    inputDirectory = inputFilePath.parent
    inputFileName = inputFilePath.name
    inputFileType = inputFilePath.suffix.lower()
    if inputFileType == '.json':
        inputJSON = open(inputFilePath, 'rb')
        inputData = json.load(inputJSON)
        inputData = objectify(inputData)
    elif inputFileType == '.xml':
        # Open the file and read the contents
        with open(inputFilePath, 'r', encoding='utf-8') as xmlFID:
            xmlString = xmlFID.read()
            inputData = xmltodict.parse(xmlString)
    elif inputFileType == '.bsdf':
        inputData = bsdf.load(str(inputFilePath))
        inputData = objectify(inputData)
    elif inputFileType == '.mat':
        _ = octave.addpath('./src_octave')
        inputData = octave.loadOctaveFile(str(inputFilePath), "-v7", nout=1)  # saves a version 7 MAT file of the outputData
        inputData = dictify(inputData)
        inputData = objectify(inputData)
    elif inputFileType == '.hdf5':
        _ = octave.addpath('./src_octave')
        inputData = octave.loadOctaveFile(str(inputFilePath), "-hdf5", nout=1)  # saves a version 7 MAT file of the outputData
        inputData = dictify(inputData)
        inputData = objectify(inputData)
    else:
        print("Data format is invalid.  Choose from: .json, .xml, .bsdf, .mat, .hdf5")
        return None
    print("I am exiting loadMyData().")
    return inputData
def dictify(myInput):
    if myInput is None: myOutput = []
    elif isinstance(myInput,(str,int,bool,float)): myOutput = myInput
    elif isinstance(myInput, pl.PurePath): myOutput = str(myInput)
    elif isinstance(myInput, oct2py.io.Cell): myOutput = list(myInput)
    elif isinstance(myInput,(np.int64,np.dtypes.Int64DType)): myOutput = (np.array(myInput)).tolist()
    elif isinstance(myInput, np.ndarray): myOutput = dictify(myInput.tolist())
    elif isinstance(myInput,tuple): myOutput = dictify(list(myInput))
    elif isinstance(myInput,list):
        myOutput = myInput
        for k in range(len(myOutput)):
            myOutput[k] = dictify(myOutput[k])
    elif isinstance(myInput, oct2py.io.Struct):
        myOutput = copy.deepcopy(myInput)
        myOutput = myOutput.__dict__
        outputKeys = list(myOutput.keys())
        if any(x=='shape' for x in outputKeys): del myOutput['shape']
        myOutput = dictify(myOutput)
    elif isinstance(myInput,dict):
        myOutput = copy.deepcopy(myInput)
        outputKeys = list(myOutput.keys())
        if any(x=='shape' for x in outputKeys):
            myOutput['myShape'] = myOutput['shape']
            del myOutput['shape']
            outputKeys = list(myOutput.keys())
        elif any(x=='_shape' for x in outputKeys):
            myOutput['myShape'] = myOutput['_shape']
            del myOutput['_shape']
            outputKeys = list(myOutput.keys())
        else: pass
        for k in range(len(outputKeys)):
            myOutput[outputKeys[k]] = dictify(myOutput[outputKeys[k]])
    else:
        myOutput = myInput.__dict__
        myOutput['myClass'] = (myInput.__class__).__name__
        myOutput = dictify(myOutput)
    return myOutput
def objectify(myInput):
    if isinstance(myInput,list): myOutput = [objectify(x) for x in myInput]
    elif isinstance(myInput,dict):
        if 'myClass' in myInput:
            if myInput['myClass'] == 'coo_array':
                myInput = sanitizeCOOArray(myInput)
                myOutput = coo_array((myInput['data'], myInput['coords']), shape=myInput['myShape'])
            elif myInput['myClass'] == 'COO':
                myInput = sanitizeCOOArray(myInput)
                myOutput = COO(myInput['coords'], myInput['data'], shape=myInput['myShape'])
            else:
                myOutput = createObject(myInput['myClass'])
                outputKeys = list(myInput.keys())
                for k in range(len(outputKeys)):
                    setattr(myOutput,outputKeys[k],objectify(myInput[outputKeys[k]]))
        else:
            myOutput = GenericClass()
            outputKeys = list(myInput.keys())
            for k in range(len(outputKeys)):
                myOutput.__dict__[k] = objectify(myInput[outputKeys[k]])
    else:
        myOutput = myInput
    return myOutput
def createObject(className, *args, **kwargs):
    try: return globals()[className](*args, **kwargs)
    except: return GenericClass()
def sanitizeCOOArray(myInput):
    if len(myInput['myShape']) > 0:                      # Check if the Shape List is empty
        if not isinstance(myInput['myShape'][0], int):      # Check if the Shape List is a list of integers
            myInput['myShape'] = [int(x) for x in myInput['myShape'][0]]
        else: pass
    else: pass
    if isinstance(myInput['data'],(str,int,bool,float)):
        myInput['data'] = [myInput['data']]
    elif len(myInput['coords'][0]) != len(myInput['data']):   # Check if the Coords List is the right size
        myInput['data'] = myInput['data'][0]
    else:
        pass
    if len(myInput['coords'][0]) > 0:                       # Check if the Coords List is a List of Integers
        if not isinstance(myInput['coords'][0][0], int):
            for k1 in range(len(myInput['coords'])):
                myInput['coords'][k1] = [int(x) for x in myInput['coords'][k1]]
        else: pass
    else: pass
    return myInput
def tileSparseMatrix(A, reps,dir='row'):
    """Tile a sparse matrix A along rows and columns."""
    if not isinstance(A, coo_array):  A = coo_array(A)  # Convert to COO format if necessary
    if dir == 'row':
        numCols = A.shape[1]
        row = np.repeat(A.row, reps)
        col = (np.tile(numCols * np.arange(reps),(A.nnz,1)) + A.col[:,np.newaxis]).flatten()
        data = np.repeat(A.data, reps)
        A2 = coo_array((data, (row, col)), shape=(A.shape[0], A.shape[1] * reps))
    elif dir == 'col':
        numRows = A.shape[0]
        row = (np.tile(numRows * np.arange(reps), (A.nnz, 1)) + A.row[:, np.newaxis]).flatten()
        col = np.repeat(A.col, reps)
        data = np.repeat(A.data, reps)
        A2 = coo_array((data, (row, col)), shape=(A.shape[0]*reps, A.shape[1]))
    else:
        print('Error! Invalid direction parameter! Either row or col. Abort! Abort!')
        exit()
    return A2
def debugEquivObjs(objA,objB,myString=""):
    if type(objA) != type(objB):
        print('ObjA and ObjB are not the same type!... Exiting()')
        myResult = False
    else:
        if objA is None: myResult = objA == objB
        elif isinstance(objA, (str, int, bool, float,list)):
            if objA == objB: myResult = True
        elif isinstance(objA,dict):
            if objA == objB: myResult = True
            else:
                print('Investigating...')
                myResult = False
                if list(objA.keys()) != list(objB.keys()):
                    print('Keys of Obj A and Obj A are not equivalent! See ' + str(set(objA).difference(set(objB))))
                else:
                    outputKeys = list(objA.keys())
                    for k in range(len(outputKeys)):
                        myResult,tempString = debugEquivObjs(objA[outputKeys[k]], objA[outputKeys[k]], myString + '.' + outputKeys[k])
                        if not myResult:
                            print('Values of Obj A and Obj A are not equivalent! See ' + tempString)
                            myString = tempString
                            break
                    print('Congratulations! ObjA and ObjB are equivalent dictionaries!')
        else:
            myResult,myString = debugEquivObjs(dictify(objA),dictify(objB),myString)
    return myResult,myString
@njit
def isin_numba_set(arr1, arr2):
    set2 = set(arr2)
    myResult = np.zeros(arr1.shape, dtype=np.bool_)
    for i in range(len(arr1)):
        if arr1[i] in set2:
            myResult[i] = True
    return myResult
