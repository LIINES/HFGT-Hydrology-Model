"""
Copyright (c) 2018-2024 Engineering Systems Analytics LLC
@author: Amro M. Farid
@version 4.0
@Note:  Version 4.0 is a major release constituting a full rewrite of the entire code base.
@Acknowledgement:  Thanks goes to Dr. Amro M. Farid, Dr. Wester C. H. Schoonenberg, and Dr. Dakota Thompson as the principal
                    authors of Versions 1, 2, 3 respectively.
@Modified: 06/01/2024
@ Provided under the Creative Commons 4.0 License
"""

import sys
from classLFES import runHFGTAnalysis

if __name__ == '__main__':
    if len(sys.argv) == 2:
        xml_file = sys.argv[1]
        myLFES = runHFGTAnalysis(xml_file)
    else:
        print('Usage: python src_python/PyHFGTToolbox_Analysis.py <input_xml_path>')

