function outputData = loadOctaveFile(inputFilePath, opt) 
load(inputFilePath, opt);