function saveOctaveFile(outputFilePath,outputData, opt) 
save(outputFilePath,"outputData", opt)