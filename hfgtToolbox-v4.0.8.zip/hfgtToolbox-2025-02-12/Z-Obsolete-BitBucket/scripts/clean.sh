#!/bin/bash
rm -r dist
rm -r output
rm -r results
rm -r docs/build
rm -r docs/source/_static
