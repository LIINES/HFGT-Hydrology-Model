#!/bin/bash
pip-licenses -f md > docs/source/licenses.md
