tests package
=============

Submodules
----------

tests.test\_example module
--------------------------

.. automodule:: tests.test_example
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tests
   :members:
   :undoc-members:
   :show-inheritance:
