# Welcome to documentation for the python-hfgt-toolbox project

```{toctree}
:caption: 'Contents:'
:maxdepth: 2
```

# Project Readme

See here for project {doc}`readme`

# Software Licenses

See here for this project's 3rd party [licenses.md](./licenses.md)

# UML Diagrams

<a href="_static/packages.html">Package UML Diagram

<a href="_static/classes.html">Class UML Diagram

# Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
