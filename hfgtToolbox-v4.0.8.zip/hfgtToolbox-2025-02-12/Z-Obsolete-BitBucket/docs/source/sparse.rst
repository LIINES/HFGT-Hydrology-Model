sparse package
==============

Module contents
---------------

.. automodule:: sparse
   :members:
   :undoc-members:
   :show-inheritance:
