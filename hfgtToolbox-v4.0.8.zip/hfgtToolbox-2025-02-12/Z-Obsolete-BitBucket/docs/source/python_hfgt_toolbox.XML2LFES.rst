python\_hfgt\_toolbox.XML2LFES package
======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   python_hfgt_toolbox.XML2LFES.XML2LFES_Classes
   python_hfgt_toolbox.XML2LFES.XML2LFES_Functions

Submodules
----------

python\_hfgt\_toolbox.XML2LFES.XML2LFES module
----------------------------------------------

.. automodule:: python_hfgt_toolbox.XML2LFES.XML2LFES
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: python_hfgt_toolbox.XML2LFES
   :members:
   :undoc-members:
   :show-inheritance:
