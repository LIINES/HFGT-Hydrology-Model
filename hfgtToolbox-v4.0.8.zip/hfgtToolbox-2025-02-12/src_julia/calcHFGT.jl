# Copyright Engineering Systems Analytics LLC 2025
# Author:  Dr. Amro M. Farid

using HDF5, SparseArrays

function dict2sparse(myDict)
    tempData = vec(myDict["data"]["value"])
    tempCoords = convert.(Int64,myDict["coords"]["value"] .+ 1)
    tempShape = convert.(Int64,myDict["myShape"]["value"])
    print(tempShape)
    A = sparse(vec(tempCoords[1,:]), vec(tempCoords[2,:]), tempData, tempShape[1], tempShape[2])
    return A
end

function getElVec(idx, n)
    return SparseVector(n, [idx], [1])
end

#fid = h5open("../1_Output_Data/myLFES-Mini-ExampleNetwork-Default-Base-2025-02-03.hdf5", "r")
fid = h5open("../1_Output_Data/myLFES-Mini-Chesapeake Bay System-Default-Base Scenario-2025-02-03.hdf5", "r")
myLFES = read(fid, "outputData")
close(fid)

i = 1
y1 = 1 
MLPNegMU = myLFES["value"]["MLPNegMU"]["value"]
MLPNegG  = myLFES["value"]["MLPNegG"]["value"]
numOperands = convert(Int64,myLFES["value"]["numOperands"]["value"])
numTransformationResource = convert(Int64,myLFES["value"]["numTransformationResource"]["value"])
numTransformProcess = convert(Int64,myLFES["value"]["numTransformProcess"]["value"])
numBuffer = convert(Int64,myLFES["value"]["numBuffer"]["value"])
numPhysicalResource = convert(Int64,myLFES["value"]["numPhysicalResource"]["value"])
idxChiCapability = convert.(Int64,myLFES["value"]["idxChiCapability"]["value"])[:] .+ 1

MLPNegMU = dict2sparse(MLPNegMU)
MLPNegG  = dict2sparse(MLPNegG)

e_i_L    = getElVec(i,numOperands)
e_y1_M   = getElVec(y1,numTransformationResource)
e_y1_BS  = getElVec(y1,numBuffer)

A1 = transpose(MLPNegMU) * e_i_L * transpose(e_y1_M)  # In Python: A1 = (MLPNegMU.T).dot(e_i_L.dot(e_y1_M.T))
numCols = numPhysicalResource - numTransformationResource
A2 = spzeros(convert(Int64,numTransformProcess),convert(Int64,numCols))
A = [A1 A2]

B1 = transpose(MLPNegG) * e_i_L # In Python:  B1 = (MLPNegG.T).dot(e_i_L)
B2 = convert(SparseVector, kron(e_y1_BS, ones(numBuffer, 1)))
B = kron(B1, kron(B2, ones(1, numPhysicalResource)))

X = [A; B][idxChiCapability]

varinfo()
